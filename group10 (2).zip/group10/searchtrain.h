#include <stdio.h>
#include <string.h>

struct Trains {
    int trainNumber;
    char departure[50];
    char destination[50];
    char trainName[50];
    char departureTime[10];
    char arrivalTime[10];
    char departureDate[11];
    char arrivalDate[11];
    int full_ticket_fare;
    int half_ticket_fare;
    int disabled_fare;
    int senior_citizen_fare;
};

int search4_main() {
    FILE *file;
    struct Trains trains[100];
    int count = 0;
    char inputDeparture[50];
    char inputDestination[50];

    printf("Enter departure: ");
    scanf("%s", inputDeparture);
    printf("Enter destination: ");
    scanf("%s", inputDestination);

    file = fopen("search1.txt", "r");
    if (file == NULL) {
        printf("Could not open file search1.txt\n");
        return 1;
    }

    while (fscanf(file, "%d %s %s %s %s %s %s %s %d %d %d %d",
                  &trains[count].trainNumber,
                  trains[count].departure,
                  trains[count].destination,
                  trains[count].trainName,
                  trains[count].departureTime,
                  trains[count].arrivalTime,
                  trains[count].departureDate,
                  trains[count].arrivalDate,
                  &trains[count].full_ticket_fare,
                  &trains[count].half_ticket_fare,
                  &trains[count].disabled_fare,
                  &trains[count].senior_citizen_fare) != EOF) {
        count++;
    }

    fclose(file);

    int found = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(trains[i].departure, inputDeparture) == 0 &&
            strcmp(trains[i].destination, inputDestination) == 0) {
            printf("Train Number: %d\n", trains[i].trainNumber);
            printf("Train Name: %s\n", trains[i].trainName);
            printf("Departure: %s\n", trains[i].departure);
            printf("Destination: %s\n", trains[i].destination);
            printf("Departure Time: %s\n", trains[i].departureTime);
            printf("Arrival Time: %s\n", trains[i].arrivalTime);
            printf("Departure Date: %s\n", trains[i].departureDate);
            printf("Arrival Date: %s\n", trains[i].arrivalDate);
            printf("Full Ticket Fare: %d\n", trains[i].full_ticket_fare);
            printf("Half Ticket Fare: %d\n", trains[i].half_ticket_fare);
            printf("Disabled Fare: %d\n", trains[i].disabled_fare);
            printf("Senior Citizen Fare: %d\n", trains[i].senior_citizen_fare);
            printf("\n");
            found = 1;
        }
    }

    if (!found) {
        printf("No trains available from %s to %s\n", inputDeparture, inputDestination);
    }

    return 0;
}


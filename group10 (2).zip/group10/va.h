#include <stdio.h>

int va_main() {
    FILE *file;
    file = fopen("vavi1.txt", "w");

    if (file == NULL) {
        printf("Error opening file!");
        return 1;
    }

    fprintf(file, "1001 1500 750 500 1200\n");
    fprintf(file, "1002 1600 800 550 1300\n");
    fprintf(file, "1003 1700 850 600 1400\n");
    fprintf(file, "1004 1800 900 650 1500\n");
    fprintf(file, "1005 1900 950 700 1600\n");
    fprintf(file, "1006 2000 1000 750 1700\n");
    fprintf(file, "1007 2100 1050 800 1800\n");
    fprintf(file, "1008 2200 1100 850 1900\n");
    fprintf(file, "1009 2300 1150 900 2000\n");
    fprintf(file, "1010 2400 1200 950 2100\n");
    fprintf(file, "1011 3400 1700 1450 3100\n");
    fprintf(file, "1012 2600 1300 1050 2300\n");
    fprintf(file, "1013 2700 1350 1100 2400\n");
    fprintf(file, "1014 2800 1400 1150 2500\n");
    fprintf(file, "1015 2900 1450 1200 2600\n");
    fprintf(file, "1016 3000 1500 1250 2700\n");
    fprintf(file, "1017 3100 1550 1300 2800\n");
    fprintf(file, "1018 3200 1600 1350 2900\n");
    fprintf(file, "1019 3300 1650 1400 3000\n");
    fprintf(file, "1020 3400 1700 1450 3100\n");
    fprintf(file, "1021 3500 1750 1500 3200\n");
    fprintf(file, "1022 3600 1800 1550 3300\n");
    fprintf(file, "1023 3700 1850 1600 3400\n");
    fprintf(file, "1024 3800 1900 1650 3500\n");
    fprintf(file, "1025 3900 1950 1700 3600\n");
    fprintf(file, "1026 4000 2000 1750 3700\n");
    fprintf(file, "1027 4100 2050 1800 3800\n");
    fprintf(file, "1028 4200 2100 1850 3900\n");
    fprintf(file, "1029 4300 2150 1900 4000\n");
    fprintf(file, "1030 4400 2200 1950 4100\n");
    fprintf(file, "1031 4500 2250 2000 4200\n");
    fprintf(file, "1032 4600 2300 2050 4300\n");
    fprintf(file, "1033 4700 2350 2100 4400\n");
    fprintf(file, "1034 4800 2400 2150 4500\n");
    fprintf(file, "1035 4900 2450 2200 4600\n");
    fprintf(file, "1036 5000 2500 2250 4700\n");
    fprintf(file, "1037 5100 2550 2300 4800\n");
    fprintf(file, "1038 5200 2600 2350 4900\n");
    fprintf(file, "1039 5300 2650 2400 5000\n");
    fprintf(file, "1040 5400 2700 2450 5100\n");
    fprintf(file, "1041 5500 2750 2500 5200\n");
    fprintf(file, "1042 5600 2800 2550 5300\n");
    fprintf(file, "1043 5700 2850 2600 5400\n");
    fprintf(file, "1044 5800 2900 2650 5500\n");
    fprintf(file, "1045 5900 2950 2700 5600\n");
    fprintf(file, "1046 6000 3000 2750 5700\n");
    fprintf(file, "1047 6100 3050 2800 5800\n");
    fprintf(file, "1048 6200 3100 2850 5900\n");
    fprintf(file, "1049 6300 3150 2900 6000\n");
    fprintf(file, "1050 6400 3200 2950 6100\n");
    fprintf(file, "1051 6500 3250 3000 6200\n");
    fprintf(file, "1052 6600 3300 3050 6300\n");
    fprintf(file, "1053 6700 3350 3100 6400\n");
    fprintf(file, "1054 6800 3400 3150 6500\n");
    fprintf(file, "1055 6900 3450 3200 6600\n");
    fprintf(file, "1056 7000 3500 3250 6700\n");
    fprintf(file, "1057 7100 3550 3300 6800\n");
    fprintf(file, "1058 7200 3600 3350 6900\n");
    fprintf(file, "1059 7300 3650 3400 7000\n");
    fprintf(file, "1060 7400 3700 3450 7100\n");
    fprintf(file, "1061 7500 3750 3500 7200\n");
    fprintf(file, "1062 7600 3800 3550 7300\n");
    fprintf(file, "1063 7700 3850 3600 7400\n");
    fprintf(file, "1064 7800 3900 3650 7500\n");
    fprintf(file, "1065 7900 3950 3700 7600\n");
    fprintf(file, "1066 8000 4000 3750 7700\n");
    fprintf(file, "1067 8100 4050 3800 7800\n");
    fprintf(file, "1068 8200 4100 3850 7900\n");
    fprintf(file, "1069 8300 4150 3900 8000\n");
    fprintf(file, "1070 8400 4200 3950 8100\n");
    fprintf(file, "1071 8500 4250 4000 8200\n");
    fprintf(file, "1072 8600 4300 4050 8300\n");
    fprintf(file, "1073 8700 4350 4100 8400\n");
    fprintf(file, "1074 8800 4400 4150 8500\n");
    fprintf(file, "1075 8900 4450 4200 8600\n");
    fprintf(file, "1076 9000 4500 4250 8700\n");
    fprintf(file, "1077 9100 4550 4300 8800\n");
    fprintf(file, "1078 9200 4600 4350 8900\n");
    fprintf(file, "1079 9300 4650 4400 9000\n");
    fprintf(file, "1080 9400 4700 4450 9100\n");
    fprintf(file, "1081 9500 4750 4500 9200\n");
    fprintf(file, "1082 9600 4800 4550 9300\n");
    fprintf(file, "1083 9700 4850 4600 9400\n");
    fprintf(file, "1084 9800 4900 4650 9500\n");
    fprintf(file, "1085 9900 4950 4700 9600\n");
    fprintf(file, "1086 10000 5000 4750 9700\n");
    fprintf(file, "1087 10100 5050 4800 9800\n");
    fprintf(file, "1088 10200 5100 4850 9900\n");
    fprintf(file, "1089 10300 5150 4900 10000\n");
    fprintf(file, "1090 10400 5200 4950 10100\n");
    fprintf(file, "1091 10500 5250 5000 10200\n");
    fprintf(file, "1092 10600 5300 5050 10300\n");
    fprintf(file, "1093 10700 5350 5100 10400\n");
    fprintf(file, "1094 10800 5400 5150 10500\n");
    fprintf(file, "1095 10900 5450 5200 10600\n");
    fprintf(file, "1096 11000 5500 5250 10700\n");
    fprintf(file, "1097 11100 5550 5300 10800\n");
    fprintf(file, "1098 11200 5600 5350 10900\n");
    fprintf(file, "1099 11300 5650 5400 11000\n");
    fprintf(file, "1100 11400 5700 5450 11100\n");

    fclose(file);

    return 0;
}



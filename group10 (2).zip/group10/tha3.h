#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct TRAIN {
    int trainNumber;
    char departure[50];
    char destination[50];
    char trainName[50];
    char departureTime[10];
    char arrivalTime[10];
    char departureDate[11];
    char arrivalDate[11];
    int full_ticket_fare;
    int half_ticket_fare;
    int disabled_fare;
    int senior_citizen_fare;
};

// Define the structure for a passenger
struct Passenger_det {
    char name[50];
    char gender[10];
    int trainNumber;
    int age;
    char mobile[15];
    int isDisabled;
    int fare;
};

// Define the structure for personal details
struct PersonalDetails {
    char name[50];
    char phone[15];
    char upi_id[16];
    char bank_name[50];
    char bank_number[20];
    char bank_pass[20];
    float balance;
};

// Define the structure for a seat
struct Seat {
    int coach_number;
    int seat_number;
    int is_booked; // 0 if not booked, 1 if booked
};

struct Seat seats[850]; // Total number of seats (7*120 + 5*60 + 2*45)

// Sample array of trains from exm7.c
struct TRAIN TRAINS[110] = {
    {1001, "Salem", "Chennai", "Salem Express", "08:00", "14:00", "2024-06-06", "2024-06-07", 500, 250, 300, 350},
    {1002, "Chennai", "Delhi", "Chennai Superfast", "10:00", "20:00", "2024-06-06", "2024-06-08", 800, 400, 480, 560},
    {1003, "Mumbai", "Kolkata", "Mumbai Mail", "12:00", "18:00", "2024-06-06", "2024-06-07", 700, 350, 420, 490},
    {1004, "Bangalore", "Hyderabad", "Bangalore Express", "11:30", "17:30", "2024-06-06", "2024-06-07", 600, 300, 360, 420},
        {1005, "Delhi", "Pune", "Delhi Express", "09:15", "16:15", "2024-06-06", "2024-06-07", 900, 450, 540, 630},
        {1006, "Kolkata", "Mumbai", "Kolkata Superfast", "08:45", "15:45", "2024-06-06", "2024-06-07", 750, 375, 450, 525},
        {1007, "Pune", "Hyderabad", "Pune Express", "10:30", "17:30", "2024-06-06", "2024-06-07", 650, 325, 390, 455},
        {1008, "Hyderabad", "Chennai", "Hyderabad Superfast", "11:00", "17:00", "2024-06-06", "2024-06-07", 550, 275, 330, 385},
        {1009, "Chennai", "Bangalore", "Chennai Express", "13:00", "19:00", "2024-06-06", "2024-06-07", 850, 425, 510, 595},
        {1010, "Bangalore", "Delhi", "Bangalore Mail", "12:30", "20:30", "2024-06-06", "2024-06-07", 1000, 500, 600, 700},
        {1011, "Salem", "Chennai", "ChennaiExpress", "06:00", "12:00", "2024-06-17", "2024-06-17", 150, 75, 50, 100},
        {1012, "Bangalore", "Hyderabad", "HyderabadExpress", "08:00", "16:00", "2024-06-18", "2024-06-18", 200, 100, 70, 150},
        {1013, "Delhi", "Mumbai", "RajdhaniExpress", "09:00", "19:00", "2024-06-19", "2024-06-19", 250, 125, 90, 200},
        {1014, "Delhi", "Chennai", "MCExpress", "4:00", "5:00", "2024-06-17", "2024-06-19", 250, 125, 90, 200},
        {1015, "Chennai", "Delhi", "ChennaiSuperfast", "06:45", "16:45", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1016, "Mumbai", "Hyderabad", "MumbaiExpress", "09:00", "19:00", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1017, "Delhi", "Chennai", "DelhiMail", "11:15", "21:15", "2024-06-07", "2024-06-08", 1000, 500, 600, 700},
        {1018, "Kolkata", "Pune", "KolkataSuperfast", "08:00", "20:00", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1019, "Bangalore", "Chennai", "BangaloreExpress", "10:30", "18:30", "2024-06-07", "2024-06-08", 800, 400, 480, 560},
        {1020, "Hyderabad", "Delhi", "HyderabadMail", "13:45", "23:45", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1021, "Pune", "Kolkata", "PuneExpress", "12:00", "22:00", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1022, "Chennai", "Bangalore", "ChennaiMail", "15:15", "23:15", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1023, "Mumbai", "Delhi", "MumbaiSuperfast", "06:45", "16:45", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1024, "Bangalore", "Hyderabad", "BangaloreExpress", "08:30", "18:30", "2024-06-07", "2024-06-08", 800, 400, 480, 560},
        {1025, "Delhi", "Mumbai", "DelhiMail", "10:15", "20:15", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1026, "Kolkata", "Bangalore", "KolkataSuperfast", "12:45", "22:45", "2024-06-07", "2024-06-08", 1000, 500, 600, 700},
        {1027, "Chennai", "Hyderabad", "ChennaiExpress", "11:00", "21:00", "2024-06-07", "2024-06-08", 750, 375, 450, 525},
        {1028, "Mumbai", "Pune", "MumbaiExpress", "15:30", "23:30", "2024-06-07", "2024-06-08", 700, 350, 420, 490},
        {1029, "Delhi", "Bangalore", "DelhiSuperfast", "06:45", "16:45", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1030, "Bangalore", "Delhi", "BangaloreExpress", "09:00", "19:00", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1031, "Hyderabad", "Mumbai", "HyderabadMail", "11:15", "21:15", "2024-06-07", "2024-06-08", 1000, 500, 600, 700},
        {1032, "Pune", "Chennai", "PuneSuperfast", "08:00", "20:00", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1033, "Chennai", "Delhi", "ChennaiMail", "10:30", "20:30", "2024-06-07", "2024-06-08", 800, 400, 480, 560},
        {1034, "Bangalore", "Hyderabad", "BangaloreExpress", "13:45", "23:45", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1035, "Delhi", "Pune", "DelhiExpress", "12:00", "22:00", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1036, "Mumbai", "Kolkata", "MumbaiSuperfast", "06:00", "14:00", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1037, "Bangalore", "Pune", "BangaloreMail", "07:45", "15:45", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1038, "Hyderabad", "Chennai", "HyderabadExpress", "08:30", "18:30", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1039, "Pune", "Delhi", "PuneExpress", "10:15", "20:15", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1040, "Chennai", "Mumbai", "ChennaiSuperfast", "11:30", "21:30", "2024-06-07", "2024-06-08", 800, 400, 480, 560},
        {1041, "Delhi", "Kolkata", "DelhiSuperfast", "12:45", "22:45", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1042, "Kolkata", "Hyderabad", "KolkataExpress", "14:00", "00:00", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1043, "Bangalore", "Mumbai", "BangaloreSuperfast", "15:15", "01:15", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1044, "Hyderabad", "Pune", "HyderabadMail", "06:30", "16:30", "2024-06-07", "2024-06-08", 1000, 500, 600, 700},
        {1045, "Pune", "Chennai", "PuneMail", "08:00", "18:00", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1046, "Chennai", "Delhi", "ChennaiExpress", "09:45", "19:45", "2024-06-07", "2024-06-08", 900, 450, 540, 630},
        {1047, "Delhi", "Bangalore", "DelhiSuperfast", "11:00", "21:00", "2024-06-07", "2024-06-08", 950, 475, 570, 665},
        {1048, "Kolkata", "Mumbai", "KolkataMail", "12:15", "22:15", "2024-06-07", "2024-06-08", 800, 400, 480, 560},
        {1049, "Mumbai", "Hyderabad", "MumbaiExpress", "13:30", "23:30", "2024-06-07", "2024-06-08", 750, 375, 450, 525},
        {1050, "Bangalore", "Delhi", "BangaloreSuperfast", "14:45", "00:45", "2024-06-07", "2024-06-08", 850, 425, 510, 595},
        {1051, "Bangalore", "Mumbai", "Bangalore Superfast", "13:15", "20:15", "2024-06-06", "2024-06-07", 810, 405, 486, 567},
{1052, "Mumbai", "Delhi", "Mumbai Mail", "14:30", "21:30", "2024-06-06", "2024-06-07", 660, 330, 396, 462},
{1053, "Delhi", "Kolkata", "Delhi Express", "15:45", "22:45", "2024-06-06", "2024-06-07", 870, 435, 522, 609},
{1054, "Kolkata", "Pune", "Kolkata Mail", "17:00", "00:00", "2024-06-06", "2024-06-07", 750, 375, 450, 525},
{1055, "Pune", "Chennai", "Pune Express", "18:15", "01:15", "2024-06-06", "2024-06-07", 690, 345, 414, 483},
{1056, "Chennai", "Hyderabad", "Chennai Superfast", "19:30", "02:30", "2024-06-06", "2024-06-07", 900, 450, 540, 630},
{1057, "Hyderabad", "Bangalore", "Hyderabad Express", "20:45", "03:45", "2024-06-06", "2024-06-07", 780, 390, 468, 546},
{1058, "Bangalore", "Mumbai", "Bangalore Superfast", "22:00", "05:00", "2024-06-06", "2024-06-07", 990, 495, 594, 693},
{1059, "Mumbai", "Delhi", "Mumbai Mail", "23:15", "06:15", "2024-06-06", "2024-06-07", 720, 360, 432, 504},
{1060, "Delhi", "Kolkata", "Delhi Express", "00:30", "07:30", "2024-06-06", "2024-06-07", 870, 435, 522},
{1061, "Kolkata", "Pune", "Kolkata Superfast", "01:45", "08:45", "2024-06-06", "2024-06-07", 600, 300, 250, 400},
{1062, "Pune", "Chennai", "Pune Mail", "03:00", "10:00", "2024-06-06", "2024-06-07", 700, 350, 300, 450},
{1063, "Chennai", "Hyderabad", "Chennai Superfast", "04:15", "11:15", "2024-06-06", "2024-06-07", 800, 400, 350, 500},
{1064, "Hyderabad", "Bangalore", "Hyderabad Express", "05:30", "12:30", "2024-06-06", "2024-06-07", 900, 450, 400, 550},
{1065, "Bangalore", "Mumbai", "Bangalore Superfast", "06:45", "13:45", "2024-06-06", "2024-06-07", 1000, 500, 450, 600},
{1066, "Mumbai", "Delhi", "Mumbai Mail", "08:00", "15:00", "2024-06-06", "2024-06-07", 1100, 550, 500, 650},
{1067, "Delhi", "Kolkata", "Delhi Superfast", "09:15", "16:15", "2024-06-06", "2024-06-07", 1200, 600, 550, 700},
{1068, "Kolkata", "Pune", "Kolkata Mail", "10:30", "17:30", "2024-06-06", "2024-06-07", 1300, 650, 600, 750},
{1069, "Pune", "Chennai", "Pune Express", "11:45", "18:45", "2024-06-06", "2024-06-07", 1400, 700, 650, 800},
{1070, "Chennai", "Hyderabad", "Chennai Superfast", "13:00", "20:00", "2024-06-06", "2024-06-07", 1500, 750, 700, 850},
{1071, "Hyderabad", "Bangalore", "Hyderabad Express", "14:15", "21:15", "2024-06-06", "2024-06-07", 1600, 800, 750, 900},
{1072, "Bangalore", "Mumbai", "Bangalore Superfast", "15:30", "22:30", "2024-06-06", "2024-06-07", 1700, 850, 800, 950},
{1073, "Mumbai", "Delhi", "Mumbai Mail", "16:45", "23:45", "2024-06-06", "2024-06-07", 1800, 900, 850, 1000},
{1074, "Delhi", "Kolkata", "Delhi Express", "18:00", "01:00", "2024-06-06", "2024-06-07", 1900, 950, 900, 1050},
{1075, "Kolkata", "Pune", "Kolkata Mail", "19:15", "02:15", "2024-06-06", "2024-06-07", 2000, 1000, 950, 1100},
{1076, "Pune", "Chennai", "Pune Express", "20:30", "03:30", "2024-06-06", "2024-06-07", 2100, 1050, 1000, 1150},
{1077, "Chennai", "Hyderabad", "Chennai Superfast", "21:45", "04:45", "2024-06-06", "2024-06-07", 2200, 1100, 1050, 1200},
{1078, "Hyderabad", "Bangalore", "Hyderabad Express", "23:00", "06:00", "2024-06-06", "2024-06-07", 2300, 1150, 1100, 1250},
{1079, "Bangalore", "Mumbai", "Bangalore Superfast", "00:15", "07:15", "2024-06-06", "2024-06-07", 2400, 1200, 1150, 1300},
{1080, "Mumbai", "Delhi", "Mumbai Mail", "01:30", "08:30", "2024-06-06", "2024-06-07", 2500, 1250, 1200, 1350},
{1081, "Delhi", "Kolkata", "Delhi Express", "02:45", "09:45", "2024-06-06", "2024-06-07", 2600, 1300, 1250, 1400},
{1082, "Kolkata", "Pune", "Kolkata Mail", "04:00", "11:00", "2024-06-06", "2024-06-07", 2700, 1350, 1300, 1450},
{1083, "Pune", "Chennai", "Pune Express", "05:15", "12:15", "2024-06-06", "2024-06-07", 2800, 1400, 1350, 1500},
{1084, "Chennai", "Hyderabad", "Chennai Superfast", "06:30", "13:30", "2024-06-06", "2024-06-07", 2900, 1450, 1400, 1550},
{1085, "Hyderabad", "Bangalore", "Hyderabad Express", "07:45", "14:45", "2024-06-06", "2024-06-07", 3000, 1500, 1450, 1600},
{1086, "Bangalore", "Mumbai", "Bangalore Superfast", "09:00", "16:00", "2024-06-06", "2024-06-07", 3100, 1550, 1500, 1650},
{1087, "Mumbai", "Delhi", "Mumbai Mail", "10:15", "17:15", "2024-06-06", "2024-06-07", 3200, 1600, 1550, 1700},
{1088, "Delhi", "Kolkata", "Delhi Express", "11:30", "18:30", "2024-06-06", "2024-06-07", 3300, 1650, 1600, 1750},
{1089, "Kolkata", "Pune", "Kolkata Mail", "12:45", "19:45", "2024-06-06", "2024-06-07", 3400, 1700, 1650, 1800},
{1090, "Pune", "Chennai", "Pune Express", "14:00", "21:00", "2024-06-06", "2024-06-07", 3500, 1750, 1700, 1850},
{1091, "Chennai", "Hyderabad", "Chennai Superfast", "15:15", "22:15", "2024-06-06", "2024-06-07", 3600, 1800, 1750, 1900},
{1092, "Hyderabad", "Bangalore", "Hyderabad Express", "16:30", "23:30", "2024-06-06", "2024-06-07", 3700, 1850, 1800, 1950},
{1093, "Bangalore", "Mumbai", "Bangalore Superfast", "17:45", "00:45", "2024-06-06", "2024-06-07", 3800, 1900, 1850, 2000},
{1094, "Mumbai", "Delhi", "Mumbai Mail", "19:00", "02:00", "2024-06-06", "2024-06-07", 3900, 1950, 1900, 2050},
{1095, "Delhi", "Kolkata", "Delhi Express", "20:15", "03:15", "2024-06-06", "2024-06-07", 4000, 2000, 1950, 2100},
{1096, "Kolkata", "Pune", "Kolkata Mail", "21:30", "04:30", "2024-06-06", "2024-06-07", 4100, 2050, 2000, 2150},
{1097, "Pune", "Chennai", "Pune Express", "22:45", "05:45", "2024-06-06", "2024-06-07", 4200, 2100, 2050, 2200},
{1098, "Chennai", "Hyderabad", "Chennai Superfast", "00:00", "07:00", "2024-06-06", "2024-06-07", 4300, 2150, 2100, 2250},
{1099, "Hyderabad", "Bangalore", "Hyderabad Express", "01:15", "08:15", "2024-06-06", "2024-06-07", 4400, 2200, 2150, 2300},
{1100, "Bangalore", "Mumbai", "Bangalore Superfast", "02:30", "09:30", "2024-06-06", "2024-06-07", 4500, 2250, 2200, 2350},
{1101, "Mumbai", "Delhi", "Mumbai Mail", "03:45", "10:45", "2024-06-06", "2024-06-07", 4600, 2300, 2250, 2400},
{1102, "Delhi", "Kolkata", "Delhi Express", "05:00", "12:00", "2024-06-06", "2024-06-07", 4700, 2350, 2300, 2450},
{1103, "Kolkata", "Pune", "Kolkata Mail", "06:15", "13:15", "2024-06-06", "2024-06-07", 4800, 2400, 2350, 2500},
{1104, "Pune", "Chennai", "Pune Express", "07:30", "14:30", "2024-06-06", "2024-06-07", 4900, 2450, 2400, 2550},
{1105, "Chennai", "Hyderabad", "Chennai Superfast", "08:45", "15:45", "2024-06-06", "2024-06-07", 5000, 2500, 2450, 2600},
{1106, "Hyderabad", "Bangalore", "Hyderabad Express", "10:00", "17:00", "2024-06-06", "2024-06-07", 5100, 2550, 2500, 2650},
{1107, "Bangalore", "Mumbai", "Bangalore Superfast", "11:15", "18:15", "2024-06-06", "2024-06-07", 5200, 2600, 2550, 2700},
{1108, "Mumbai", "Delhi", "Mumbai Mail", "12:30", "19:30", "2024-06-06", "2024-06-07", 5300, 2650, 2600, 2750},
{1109, "Delhi", "Kolkata", "Delhi Express", "13:45", "20:45", "2024-06-06", "2024-06-07", 5400, 2700, 2650, 2800},
{1110, "Kolkata", "Pune", "Kolkata Mail", "15:00", "22:00", "2024-06-06", "2024-06-07", 5500, 2750, 2700, 2850}

//{1110, "Kolkata", "Pune", "Kolkata Mail", "15:00", "22:00", "2024-06-06", "2024-06-07", 5500, 2750, 2700, 2850}
};

// Function to initialize seats
void initialize_seats() {
    int i = 0;
    for (int c = 1; c <= 7; c++) {
        for (int s = 1; s <= 120; s++) {
            seats[i].coach_number = c;
            seats[i].seat_number = s;
            seats[i].is_booked = 0;
            i++;
        }
    }
    for (int c = 1; c <= 5; c++) {
        for (int s = 1; s <= 60; s++) {
            seats[i].coach_number = c;
            seats[i].seat_number = s;
            seats[i].is_booked = 0;
            i++;
        }
    }
    for (int c = 1; c <= 2; c++) {
        for (int s = 1; s <= 45; s++) {
            seats[i].coach_number = c;
            seats[i].seat_number = s;
            seats[i].is_booked = 0;
            i++;
        }
    }
}

// Function to load booked seats from a file
void load_booked_seats(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening booked seats file");
        return;
    }

    char type[10];
    int coach, seat;
    while (fscanf(file, "%s %d %d", type, &coach, &seat) != EOF) {
        int start_index = 0;
        int max_seats = 0;

        if (strcmp(type, "N") == 0) {
            start_index = 0;
            max_seats = 120;
        } else if (strcmp(type, "AC") == 0) {
            start_index = 7 * 120;
            max_seats = 60;
        } else if (strcmp(type, "E") == 0) {
            start_index = 7 * 120 + 5 * 60;
            max_seats = 45;
        }

        int index = start_index + (coach - 1) * max_seats + (seat - 1);
        seats[index].is_booked = 1;
    }

    fclose(file);
}

// Function to display available seats
void display_seats(int coach, int max_seats, char *type) {
    int start_index = 0;
    if (strcmp(type, "N") == 0) {
        start_index = 0;
    } else if (strcmp(type, "AC") == 0) {
        start_index = 7 * 120;
    } else if (strcmp(type, "E") == 0) {
        start_index = 7 * 120 + 5 * 60;
    }

    printf("Seats in coach %d (%s):\n", coach, type);
    for (int i = start_index + (coach - 1) * max_seats; i < start_index + coach * max_seats; i++) {
        if (seats[i].is_booked == 0) {
            printf("Seat %d: Available\n", seats[i].seat_number);
        } else {
            printf("Seat %d: Booked\n", seats[i].seat_number);
        }
    }
}

// Function to book a seat
void book_seat(char *type, int coach, int seat, int max_seats) {
    int start_index = 0;
    if (strcmp(type, "N") == 0) {
        start_index = 0;
    } else if (strcmp(type, "AC") == 0) {
        start_index = 7 * 120;
    } else if (strcmp(type, "E") == 0) {
        start_index = 7 * 120 + 5 * 60;
    }

    int index = start_index + (coach - 1) * max_seats + (seat - 1);
    if (seats[index].is_booked == 0) {
        seats[index].is_booked = 1;
        printf("Seat %d in coach %d (%s) successfully booked.\n", seat, coach, type);
    } else {
        printf("Seat %d in coach %d (%s) is already booked.\n", seat, coach, type);
    }
}

// Function to save booking details to a file
void save_booking(const char *filename, const char *type, int coach, int seat) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        perror("Error opening booking file");
        return;
    }
    fprintf(file, "%s %d %d\n", type, coach, seat);
    fclose(file);
}

// Function to calculate fare from exm7.c
int calculateFare(int trainNumber, int age, int isDisabled) {
    for (int i = 0; i < 110; i++) {
        if (TRAINS[i].trainNumber == trainNumber) {
            if (isDisabled) {
                return TRAINS[i].disabled_fare;
            } else if (age < 12) {
                return TRAINS[i].half_ticket_fare;
            } else if (age >= 60) {
                return TRAINS[i].senior_citizen_fare;
            } else {
                return TRAINS[i].full_ticket_fare;
            }
        }
    }
    return -1; // Train number not found
}

int tha3_main() {
    initialize_seats();
    load_booked_seats("booked_seats.txt");

    char continue_booking;
    do {
        struct Passenger_det passenger;
        printf("Enter your name: ");
        scanf("%s", passenger.name);
        printf("Enter your gender: ");
        scanf("%s", passenger.gender);
        printf("Enter train number: ");
        scanf("%d", &passenger.trainNumber);
        printf("Enter your age: ");
        scanf("%d", &passenger.age);
        printf("Enter your mobile number: ");
        scanf("%s", passenger.mobile);
        printf("Are you disabled? (1 for Yes, 0 for No): ");
        scanf("%d", &passenger.isDisabled);

        // Calculate fare using the function from exm7.c
        passenger.fare = calculateFare(passenger.trainNumber, passenger.age, passenger.isDisabled);
        if (passenger.fare == -1) {
            printf("Invalid train number.\n");
            return 1;
        }

        int coach, seat;
        char type[10];
        int choice;

        printf("Choose seat type:\n");
        printf("1. Normal (N)\n");
        printf("2. AC (AC)\n");
        printf("3. Executive (E)\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            strcpy(type, "N");
        } else if (choice == 2) {
            strcpy(type, "AC");
            passenger.fare += 500;
        } else if (choice == 3) {
            strcpy(type, "E");
            passenger.fare += 1000;
        } else {
            printf("Invalid choice.\n");
            return 1;
        }

        printf("Your fare is: %d\n", passenger.fare);

        // Write passenger information to file
        FILE *fp_passenger = fopen("passenger_info.txt", "a");
        if (fp_passenger == NULL) {
            perror("Error opening passenger info file");
            return 1;
        }
        fprintf(fp_passenger, "%s,%s,%d,%d,%s,%d,%d\n", passenger.name, passenger.gender, passenger.trainNumber, passenger.age, passenger.mobile, passenger.isDisabled, passenger.fare);
        fclose(fp_passenger);

        printf("Enter coach number: ");
        scanf("%d", &coach);

        int max_seats = (strcmp(type, "N") == 0) ? 120 : (strcmp(type, "AC") == 0) ? 60 : 45;

        display_seats(coach, max_seats, type);

        printf("Enter seat number to book: ");
        scanf("%d", &seat);

        book_seat(type, coach, seat, max_seats);
        save_booking("booked_seats.txt", type, coach, seat);

        struct PersonalDetails personal;
        printf("Enter your name for personal details: ");
        scanf("%s", personal.name);
        printf("Enter your phone number for personal details: ");
        scanf("%s", personal.phone);
        printf("Enter your upi_id: ");
        scanf("%s", personal.upi_id);
        printf("Enter your bank name: ");
        scanf("%s", personal.bank_name);
        printf("Enter your bank number: ");
        scanf("%s", personal.bank_number);
        printf("Enter your bank pass number: ");
        scanf("%s", personal.bank_pass);
        printf("Enter your balance: ");
        scanf("%f", &personal.balance);

        // Write personal details to file
        FILE *fp_personal = fopen("personal_detailn3.csv", "a");
        if (fp_personal == NULL) {
            perror("Error opening personal details file");
            return 1;
        }
        fprintf(fp_personal, "%s,%s,%s,%s,%s,%s,%.2f\n", personal.name, personal.phone,personal.upi_id, personal.bank_name, personal.bank_number, personal.bank_pass, personal.balance);
        fclose(fp_personal);

        // Write to the new CSV file
        FILE *fp_summary = fopen("summaryn2.csv", "a");
        if (fp_summary == NULL) {
            perror("Error opening summary file");
            return 1;
        }
        fprintf(fp_summary, "%s,%d,%s,%s %d %d\n", passenger.name, passenger.fare, passenger.mobile, type, coach, seat);
        fclose(fp_summary);

        // Write to booked_day.txt file
        FILE *fp_booked_day = fopen("booked_day.txt", "a");
        if (fp_booked_day == NULL) {
            perror("Error opening booked_day file");
            return 1;
        }
        fprintf(fp_booked_day, "%s %d %d\n", type, coach, seat);
        fclose(fp_booked_day);

        printf("Booking and personal details have been successfully saved.\n");

        printf("Do you want to book another ticket? (y/n): ");
        scanf(" %c", &continue_booking);

    } while (continue_booking == 'y' || continue_booking == 'Y');

    return 0;
}



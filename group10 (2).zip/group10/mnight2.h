#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define WAITING_LIST_SIZE 123
#define RAC_LIST_SIZE 123
#define NAME_LENGTH 123

typedef struct {
    char name[NAME_LENGTH];
    int age;
} Passenger;

typedef Passenger RACPassenger;

Passenger waitingList[WAITING_LIST_SIZE];
RACPassenger racList[RAC_LIST_SIZE];
int numWaitingPersons = 0;
int numRACPersons = 0;

void add_Person_To_WaitingList(int *wl_seats, int noOfPassenger);
void display_List(Passenger list[], int numPersons, const char *listName);
int add_Person_To_RAC(int *rac_seats, int *wl_seats);
void handle_train_reservation(int *rac_seats, int *wl_seats, int num);

int mnight2_main() {
    int rac_seats = 10; // Example initial values for RAC seats
    int wl_seats = 20;  // Example initial values for waiting list seats
    int train_number = 1001; // Example train number

    handle_train_reservation(&rac_seats, &wl_seats, train_number);

    return 0;
}

//void add_Person_To_WaitingList(int *wl_seats, int noOfPassenger) {


void add_Person_To_WaitingList(int *wl_seats, int noOfPassenger) {
    if ((*wl_seats - noOfPassenger) < 0) {
        printf("Waiting list is full!\n");
        return;
    }
    for (int i = 0; i < noOfPassenger; i++) {
        Passenger newPerson;
        printf("Enter name: ");
        scanf("%s", newPerson.name);
        printf("Enter age: ");
        scanf("%d", &newPerson.age);
        waitingList[numWaitingPersons] = newPerson;
        printf("Your waiting list number is: %d\n", numWaitingPersons + 1);
        numWaitingPersons++;
        (*wl_seats)--;
    }
    printf("Person(s) added to waiting list successfully.\n");
}




//void display_List(Passenger list[], int numPersons, const char *listName) {
    // Implementation of display_List function
    void display_List(Passenger list[], int numPersons, const char *listName) {
    printf("%s:\n", listName);
    printf("Name\tAge\n");
    for (int i = 0; i < numPersons; i++) {
        if (list[i].age != 0) {
            printf("%s\t%d\n", list[i].name, list[i].age);
        }
    }
}



//int add_Person_To_RAC(int *rac_seats, int *wl_seats) {
    // Implementation of add_Person_To_RAC function

int add_Person_To_RAC(int *rac_seats, int *wl_seats) {
    if (*rac_seats <= 0) {
        printf("RAC list is full!\n");
        return 0;
    }

    int noOfPassengers;
    printf("Enter number of passengers: ");
    scanf("%d", &noOfPassengers);

    int rac_available = *rac_seats;
    if (noOfPassengers > rac_available) {
        printf("Only %d seats are available in RAC, adding remaining %d to waiting list...\n", rac_available, noOfPassengers - rac_available);
        for (int i = 0; i < rac_available; i++) {
            RACPassenger newRACPerson;
            printf("Enter name: ");
            scanf("%s", newRACPerson.name);
            printf("Enter age: ");
            scanf("%d", &newRACPerson.age);
            racList[numRACPersons] = newRACPerson;
            printf("Your RAC no is: %d\n", numRACPersons + 1);
            numRACPersons++;
            (*rac_seats)--;
        }
        add_Person_To_WaitingList(wl_seats, noOfPassengers - rac_available);
    } else {
        for (int i = 0; i < noOfPassengers; i++) {
            RACPassenger newRACPerson;
            printf("Enter name: ");
            scanf("%s", newRACPerson.name);
            printf("Enter age: ");
            scanf("%d", &newRACPerson.age);
            racList[numRACPersons] = newRACPerson;
            printf("Your RAC no is: %d\n", numRACPersons + 1);
            numRACPersons++;
            (*rac_seats)--;
        }
    }

    printf("Person(s) added to RAC list successfully.\n");
    return 1;
}


//void handle_train_reservation(int *rac_seats, int *wl_seats, int num) {

void handle_train_reservation(int *rac_seats, int *wl_seats, int num) {
    FILE *file = fopen("night.csv", "r");
    if (!file) {
        perror("Failed to open CSV file");
        exit(EXIT_FAILURE);
    }

    char buffer[256];
    int found = 0;
    char csv_data[500][256];  // Adjust size according to your file
    int row_count = 0;

    // Read data from the CSV file into memory
    while (fgets(buffer, sizeof(buffer), file)) {
        strcpy(csv_data[row_count], buffer);
        char *token = strtok(buffer, ",");
        if (token != NULL && atoi(token) == num) {
            found = 1;
            int column = 0;
            while (token != NULL) {
                column++;
                token = strtok(NULL, ",");
                if (column == 5 && token != NULL) {
                    *rac_seats = atoi(token);
                } else if (column == 6 && token != NULL) {
                    *wl_seats = atoi(token);
                }
            }
        }
        row_count++;
    }
    fclose(file);

    // Check if the train number was found in the CSV file
    if (!found) {
        printf("Train number not found in CSV file.\n");
        return;
    }

    // Calculate the number of persons in waiting list and RAC list
    numWaitingPersons = WAITING_LIST_SIZE - *wl_seats;
    numRACPersons = RAC_LIST_SIZE - *rac_seats;

    // Add persons to RAC list based on available seats
    int racResult = add_Person_To_RAC(rac_seats, wl_seats);
    if (!racResult) {
        // If RAC list is full, add persons directly to waiting list
        int noOfPassenger;
        printf("Enter number of passengers: ");
        scanf("%d", &noOfPassenger);
        add_Person_To_WaitingList(wl_seats, noOfPassenger);
    }

    // Update the CSV file with the updated seats information
    file = fopen("night.csv", "w");
    if (!file) {
        perror("Failed to open CSV file for writing");
        exit(EXIT_FAILURE);
    }

    // Rewrite the CSV data with updated seat information
    for (int i = 0; i < row_count; i++) {
        char temp_buffer[256];
        strcpy(temp_buffer, csv_data[i]);
        char *token = strtok(temp_buffer, ",");
        if (token != NULL && atoi(token) == num) {
            char rest_of_row[256];
            strcpy(rest_of_row, csv_data[i] + strlen(token) + 1);  // Skip past the index column
            char *fields[7];
            fields[0] = token;
            for (int j = 1; j < 7; j++) {
                fields[j] = strtok(NULL, ",");
            }
            fprintf(file, "%s,%s,%s,%s,%s,%d,%d\n",
                    fields[0], fields[1], fields[2], fields[3], fields[4], *rac_seats, *wl_seats);
        } else {
            fputs(csv_data[i], file);
        }
    }
    fclose(file);
}



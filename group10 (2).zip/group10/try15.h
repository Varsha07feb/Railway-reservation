#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct PASSENGER {
    char name[50];
    char phone_number[20];
    char upi_id[50];
    char bank_name[50];
    char bank_number[20];
    char bank_password[50];
    double balance;
};

int is_valid_phone_number(char *phone_number) {
    if (strlen(phone_number) != 10) return 0;
    for (int i = 0; i < 10; i++) {
        if (!isdigit(phone_number[i])) return 0;
    }
    return 1;
}

int check_name_and_number(char *name, char *phone_number) {
    FILE *file = fopen("passenger_info.txt", "r");
    if (file == NULL) {
        printf("Error opening passenger_info.txt!\n");
        return 0;
    }

    char line[300];
    while (fgets(line, sizeof(line), file)) {
        char stored_name[50], stored_phone_number[20], gender, travelClass[20], isDisabled[4], coach_type;
        int trainNumber, age, berth_number, fare;

        sscanf(line, "Passenger Name: %49[^,], Gender: %c, Train Number: %d, Class: %19[^,], Age: %d, Mobile Number: %19[^,], Disabled: %3[^,], Coach: %c, Berth: %d, Fare: %d\n",
               stored_name, &gender, &trainNumber, travelClass, &age, stored_phone_number, isDisabled, &coach_type, &berth_number, &fare);

        if (strcmp(name, stored_name) == 0 && strcmp(phone_number, stored_phone_number) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

void get_passenger_details(struct PASSENGER *p) {
    printf("Enter your name: ");
    scanf(" %[^\n]", p->name);

    while (1) {
        printf("Enter your phone number: ");
        scanf("%s", p->phone_number);
        if (is_valid_phone_number(p->phone_number)) break;
        else printf("Invalid phone number. Please enter a 10-digit number.\n");
    }

    printf("Enter your UPI ID: ");
    scanf("%s", p->upi_id);
    printf("Enter your bank name: ");
    scanf(" %[^\n]", p->bank_name);
    printf("Enter your bank number: ");
    scanf("%s", p->bank_number);
    printf("Enter your bank password: ");
    scanf("%s", p->bank_password);
    printf("Enter your balance: ");
    scanf("%lf", &(p->balance));
}

void save_to_csv(struct PASSENGER *p) {
    FILE *file = fopen("night_bank3.csv", "a");
    if (file == NULL) {
        printf("Error opening abcde.csv!\n");
        return;
    }
    fprintf(file, "%s,%s,%s,%s,%s,%s,%.2f\n", p->name, p->phone_number, p->upi_id, p->bank_name, p->bank_number, p->bank_password, p->balance);
    fclose(file);
}

int try15_main() {
    struct PASSENGER p;
    get_passenger_details(&p);

    if (check_name_and_number(p.name, p.phone_number)) {
        save_to_csv(&p);
        printf("Details saved to abcde.csv\n");
    } else {
        printf("Sorry! The given name and number don't exist.\n");
    }

    return 0;
}


#include <stdio.h>

// Define the structure for a train
struct Train {
    int trainNumber;
    char departure[50];
    char destination[50];
    char trainName[50];
    char departureTime[10];
    char arrivalTime[10];
    char departureDate[11];
    char arrivalDate[11];
    int full_ticket_fare;
    int half_ticket_fare;
    int disabled_fare;
    int senior_citizen_fare;
};

int exm7_main() {
    // Sample array of trains
    struct Train trains[110] = {{1001, "Salem", "Chennai", "Salem Express", "08:00", "14:00", "2024-06-06", "2024-06-07", 500, 250, 300, 350},
        {1002, "Chennai", "Delhi", "Chennai Superfast", "10:00", "20:00", "2024-06-06", "2024-06-08", 800, 400, 480, 560},
        {1003, "Mumbai", "Kolkata", "Mumbai Mail", "12:00", "18:00", "2024-06-06", "2024-06-07", 700, 350, 420, 490},
        {1004, "Bangalore", "Hyderabad", "Bangalore Express", "11:30", "17:30", "2024-06-06", "2024-06-07", 600, 300, 360, 420},
        {1005, "Delhi", "Pune", "Delhi Express", "09:15", "16:15", "2024-06-06", "2024-06-07", 900, 450, 540, 630},
        {1006, "Kolkata", "Mumbai", "Kolkata Superfast", "08:45", "15:45", "2024-06-06", "2024-06-07", 750, 375, 450, 525},
        {1007, "Pune", "Hyderabad", "Pune Express", "10:30", "17:30", "2024-06-06", "2024-06-07", 650, 325, 390, 455},
        {1008, "Hyderabad", "Chennai", "Hyderabad Superfast", "11:00", "17:00", "2024-06-06", "2024-06-07", 550, 275, 330, 385},
        {1009, "Chennai", "Bangalore", "Chennai Express", "13:00", "19:00", "2024-06-06", "2024-06-07", 850, 425, 510, 595},
        {1010, "Bangalore", "Delhi", "Bangalore Mail", "12:30", "20:30", "2024-06-06", "2024-06-07", 1000, 500, 600, 700},
{1011, "Delhi", "Kolkata", "Delhi Superfast", "14:45", "21:45", "2024-06-06", "2024-06-07", 1200.50, 600.25, 300.00, 900.75},
{1012, "Mumbai", "Pune", "Mumbai Express", "15:30", "22:30", "2024-06-06", "2024-06-07", 1100.75, 550.25, 275.00, 825.50},
{1013, "Pune", "Chennai", "Pune Superfast", "16:45", "23:45", "2024-06-06", "2024-06-07", 1300.25, 650.10, 325.00, 975.35},
{1014, "Chennai", "Hyderabad", "Chennai Mail", "17:00", "00:00", "2024-06-06", "2024-06-07", 900.35, 450.20, 225.00, 675.55},
{1015, "Hyderabad", "Bangalore", "Hyderabad Mail", "18:15", "01:15", "2024-06-06", "2024-06-07", 1000.20, 500.15, 250.00, 750.35},
{1016, "Bangalore", "Mumbai", "Bangalore Superfast", "19:30", "02:30", "2024-06-06", "2024-06-07", 1200.10, 600.05, 300.00, 900.15},
{1017, "Mumbai", "Delhi", "Mumbai Superfast", "20:45", "03:45", "2024-06-06", "2024-06-07", 1100.05, 550.03, 275.00, 825.08},
{1018, "Delhi", "Kolkata", "Delhi Mail", "21:00", "04:00", "2024-06-06", "2024-06-07", 1300.08, 650.04, 325.00, 975.12},
{1019, "Kolkata", "Pune", "Kolkata Express", "22:15", "05:15", "2024-06-06", "2024-06-07", 900.04, 450.02, 225.00, 675.06},
{1020, "Pune", "Chennai", "Pune Mail", "23:30", "06:30", "2024-06-06", "2024-06-07", 1000.02, 500.01, 250.00, 750.03},
{1021, "Chennai", "Hyderabad", "Chennai Superfast", "01:45", "08:45", "2024-06-06", "2024-06-07", 1200.01, 600.00, 300.00, 900.00},
{1022, "Hyderabad", "Bangalore", "Hyderabad Express", "02:00", "09:00", "2024-06-06", "2024-06-07", 1100.00, 550.00, 275.00, 825.00},
{1023, "Bangalore", "Mumbai", "Bangalore Superfast", "03:15", "10:15", "2024-06-06", "2024-06-07", 1300.00, 650.00, 325.00, 975.00},
{1024, "Mumbai", "Delhi", "Mumbai Mail", "04:30", "11:30", "2024-06-06", "2024-06-07", 900.00, 450.00, 225.00, 675.00},
{1025, "Delhi", "Kolkata", "Delhi Express", "05:45", "12:45", "2024-06-06", "2024-06-07", 1000.00, 500.00, 250.00, 750.00},
{1026, "Kolkata", "Pune", "Kolkata Mail", "06:00", "13:00", "2024-06-06", "2024-06-07", 1200.00, 600.00, 300.00, 900.00},
{1036, "Hyderabad", "Bangalore", "Hyderabad Express", "18:30", "01:30", "2024-06-06", "2024-06-07", 720, 360, 432, 504},
{1037, "Bangalore", "Mumbai", "Bangalore Superfast", "19:45", "02:45", "2024-06-06", "2024-06-07", 810, 405, 486, 567},
{1038, "Mumbai", "Delhi", "Mumbai Mail", "21:00", "04:00", "2024-06-06", "2024-06-07", 690, 345, 414, 483},
{1039, "Delhi", "Kolkata", "Delhi Express", "22:15", "05:15", "2024-06-06", "2024-06-07", 630, 315, 378, 441},
{1040, "Kolkata", "Pune", "Kolkata Mail", "23:30", "06:30", "2024-06-06", "2024-06-07", 750, 375, 450, 525},
{1041, "Pune", "Chennai", "Pune Express", "00:45", "07:45", "2024-06-06", "2024-06-07", 660, 330, 396, 462},
{1042, "Chennai", "Hyderabad", "Chennai Superfast", "02:00", "09:00", "2024-06-06", "2024-06-07", 840, 420, 504, 588},
{1043, "Hyderabad", "Bangalore", "Hyderabad Express", "03:15", "10:15", "2024-06-06", "2024-06-07", 780, 390, 468, 546},
{1044, "Bangalore", "Mumbai", "Bangalore Superfast", "04:30", "11:30", "2024-06-06", "2024-06-07", 900, 450, 540, 630},
{1045, "Mumbai", "Delhi", "Mumbai Mail", "05:45", "12:45", "2024-06-06", "2024-06-07", 720, 360, 432, 504},
{1046, "Delhi", "Kolkata", "Delhi Superfast", "07:00", "14:00", "2024-06-06", "2024-06-07", 990, 495, 594, 693},
{1047, "Kolkata", "Pune", "Kolkata Superfast", "08:15", "15:15", "2024-06-06", "2024-06-07", 870, 435, 522, 609},
{1048, "Pune", "Chennai", "Pune Express", "09:30", "16:30", "2024-06-06", "2024-06-07", 810, 405, 486, 567},
{1049, "Chennai", "Hyderabad", "Chennai Superfast", "10:45", "17:45", "2024-06-06", "2024-06-07", 720, 360, 432, 504},
{1050, "Hyderabad", "Bangalore", "Hyderabad Express", "12:00", "19:00", "2024-06-06", "2024-06-07", 990, 495, 594, 693},
{1051, "Bangalore", "Mumbai", "Bangalore Superfast", "13:15", "20:15", "2024-06-06", "2024-06-07", 810, 405, 486, 567},
{1052, "Mumbai", "Delhi", "Mumbai Mail", "14:30", "21:30", "2024-06-06", "2024-06-07", 660, 330, 396, 462},
{1053, "Delhi", "Kolkata", "Delhi Express", "15:45", "22:45", "2024-06-06", "2024-06-07", 870, 435, 522, 609},
{1054, "Kolkata", "Pune", "Kolkata Mail", "17:00", "00:00", "2024-06-06", "2024-06-07", 750, 375, 450, 525},
{1055, "Pune", "Chennai", "Pune Express", "18:15", "01:15", "2024-06-06", "2024-06-07", 690, 345, 414, 483},
{1056, "Chennai", "Hyderabad", "Chennai Superfast", "19:30", "02:30", "2024-06-06", "2024-06-07", 900, 450, 540, 630},
{1057, "Hyderabad", "Bangalore", "Hyderabad Express", "20:45", "03:45", "2024-06-06", "2024-06-07", 780, 390, 468, 546},
{1058, "Bangalore", "Mumbai", "Bangalore Superfast", "22:00", "05:00", "2024-06-06", "2024-06-07", 990, 495, 594, 693},
{1059, "Mumbai", "Delhi", "Mumbai Mail", "23:15", "06:15", "2024-06-06", "2024-06-07", 720, 360, 432, 504},
{1060, "Delhi", "Kolkata", "Delhi Express", "00:30", "07:30", "2024-06-06", "2024-06-07", 870, 435, 522},
{1061, "Kolkata", "Pune", "Kolkata Superfast", "01:45", "08:45", "2024-06-06", "2024-06-07", 600, 300, 250, 400},
{1062, "Pune", "Chennai", "Pune Mail", "03:00", "10:00", "2024-06-06", "2024-06-07", 700, 350, 300, 450},
{1063, "Chennai", "Hyderabad", "Chennai Superfast", "04:15", "11:15", "2024-06-06", "2024-06-07", 800, 400, 350, 500},
{1064, "Hyderabad", "Bangalore", "Hyderabad Express", "05:30", "12:30", "2024-06-06", "2024-06-07", 900, 450, 400, 550},
{1065, "Bangalore", "Mumbai", "Bangalore Superfast", "06:45", "13:45", "2024-06-06", "2024-06-07", 1000, 500, 450, 600},
{1066, "Mumbai", "Delhi", "Mumbai Mail", "08:00", "15:00", "2024-06-06", "2024-06-07", 1100, 550, 500, 650},
{1067, "Delhi", "Kolkata", "Delhi Superfast", "09:15", "16:15", "2024-06-06", "2024-06-07", 1200, 600, 550, 700},
{1068, "Kolkata", "Pune", "Kolkata Mail", "10:30", "17:30", "2024-06-06", "2024-06-07", 1300, 650, 600, 750},
{1069, "Pune", "Chennai", "Pune Express", "11:45", "18:45", "2024-06-06", "2024-06-07", 1400, 700, 650, 800},
{1070, "Chennai", "Hyderabad", "Chennai Superfast", "13:00", "20:00", "2024-06-06", "2024-06-07", 1500, 750, 700, 850},
{1071, "Hyderabad", "Bangalore", "Hyderabad Express", "14:15", "21:15", "2024-06-06", "2024-06-07", 1600, 800, 750, 900},
{1072, "Bangalore", "Mumbai", "Bangalore Superfast", "15:30", "22:30", "2024-06-06", "2024-06-07", 1700, 850, 800, 950},
{1073, "Mumbai", "Delhi", "Mumbai Mail", "16:45", "23:45", "2024-06-06", "2024-06-07", 1800, 900, 850, 1000},
{1074, "Delhi", "Kolkata", "Delhi Express", "18:00", "01:00", "2024-06-06", "2024-06-07", 1900, 950, 900, 1050},
{1075, "Kolkata", "Pune", "Kolkata Mail", "19:15", "02:15", "2024-06-06", "2024-06-07", 2000, 1000, 950, 1100},
{1076, "Pune", "Chennai", "Pune Express", "20:30", "03:30", "2024-06-06", "2024-06-07", 2100, 1050, 1000, 1150},
{1077, "Chennai", "Hyderabad", "Chennai Superfast", "21:45", "04:45", "2024-06-06", "2024-06-07", 2200, 1100, 1050, 1200},
{1078, "Hyderabad", "Bangalore", "Hyderabad Express", "23:00", "06:00", "2024-06-06", "2024-06-07", 2300, 1150, 1100, 1250},
{1079, "Bangalore", "Mumbai", "Bangalore Superfast", "00:15", "07:15", "2024-06-06", "2024-06-07", 2400, 1200, 1150, 1300},
{1080, "Mumbai", "Delhi", "Mumbai Mail", "01:30", "08:30", "2024-06-06", "2024-06-07", 2500, 1250, 1200, 1350},
{1081, "Delhi", "Kolkata", "Delhi Express", "02:45", "09:45", "2024-06-06", "2024-06-07", 2600, 1300, 1250, 1400},
{1082, "Kolkata", "Pune", "Kolkata Mail", "04:00", "11:00", "2024-06-06", "2024-06-07", 2700, 1350, 1300, 1450},
{1083, "Pune", "Chennai", "Pune Express", "05:15", "12:15", "2024-06-06", "2024-06-07", 2800, 1400, 1350, 1500},
{1084, "Chennai", "Hyderabad", "Chennai Superfast", "06:30", "13:30", "2024-06-06", "2024-06-07", 2900, 1450, 1400, 1550},
{1085, "Hyderabad", "Bangalore", "Hyderabad Express", "07:45", "14:45", "2024-06-06", "2024-06-07", 3000, 1500, 1450, 1600},
{1086, "Bangalore", "Mumbai", "Bangalore Superfast", "09:00", "16:00", "2024-06-06", "2024-06-07", 3100, 1550, 1500, 1650},
{1087, "Mumbai", "Delhi", "Mumbai Mail", "10:15", "17:15", "2024-06-06", "2024-06-07", 3200, 1600, 1550, 1700},
{1088, "Delhi", "Kolkata", "Delhi Express", "11:30", "18:30", "2024-06-06", "2024-06-07", 3300, 1650, 1600, 1750},
{1089, "Kolkata", "Pune", "Kolkata Mail", "12:45", "19:45", "2024-06-06", "2024-06-07", 3400, 1700, 1650, 1800},
{1090, "Pune", "Chennai", "Pune Express", "14:00", "21:00", "2024-06-06", "2024-06-07", 3500, 1750, 1700, 1850},
{1091, "Chennai", "Hyderabad", "Chennai Superfast", "15:15", "22:15", "2024-06-06", "2024-06-07", 3600, 1800, 1750, 1900},
{1092, "Hyderabad", "Bangalore", "Hyderabad Express", "16:30", "23:30", "2024-06-06", "2024-06-07", 3700, 1850, 1800, 1950},
{1093, "Bangalore", "Mumbai", "Bangalore Superfast", "17:45", "00:45", "2024-06-06", "2024-06-07", 3800, 1900, 1850, 2000},
{1094, "Mumbai", "Delhi", "Mumbai Mail", "19:00", "02:00", "2024-06-06", "2024-06-07", 3900, 1950, 1900, 2050},
{1095, "Delhi", "Kolkata", "Delhi Express", "20:15", "03:15", "2024-06-06", "2024-06-07", 4000, 2000, 1950, 2100},
{1096, "Kolkata", "Pune", "Kolkata Mail", "21:30", "04:30", "2024-06-06", "2024-06-07", 4100, 2050, 2000, 2150},
{1097, "Pune", "Chennai", "Pune Express", "22:45", "05:45", "2024-06-06", "2024-06-07", 4200, 2100, 2050, 2200},
{1098, "Chennai", "Hyderabad", "Chennai Superfast", "00:00", "07:00", "2024-06-06", "2024-06-07", 4300, 2150, 2100, 2250},
{1099, "Hyderabad", "Bangalore", "Hyderabad Express", "01:15", "08:15", "2024-06-06", "2024-06-07", 4400, 2200, 2150, 2300},
{1100, "Bangalore", "Mumbai", "Bangalore Superfast", "02:30", "09:30", "2024-06-06", "2024-06-07", 4500, 2250, 2200, 2350},
{1101, "Mumbai", "Delhi", "Mumbai Mail", "03:45", "10:45", "2024-06-06", "2024-06-07", 4600, 2300, 2250, 2400},
{1102, "Delhi", "Kolkata", "Delhi Express", "05:00", "12:00", "2024-06-06", "2024-06-07", 4700, 2350, 2300, 2450},
{1103, "Kolkata", "Pune", "Kolkata Mail", "06:15", "13:15", "2024-06-06", "2024-06-07", 4800, 2400, 2350, 2500},
{1104, "Pune", "Chennai", "Pune Express", "07:30", "14:30", "2024-06-06", "2024-06-07", 4900, 2450, 2400, 2550},
{1105, "Chennai", "Hyderabad", "Chennai Superfast", "08:45", "15:45", "2024-06-06", "2024-06-07", 5000, 2500, 2450, 2600},
{1106, "Hyderabad", "Bangalore", "Hyderabad Express", "10:00", "17:00", "2024-06-06", "2024-06-07", 5100, 2550, 2500, 2650},
{1107, "Bangalore", "Mumbai", "Bangalore Superfast", "11:15", "18:15", "2024-06-06", "2024-06-07", 5200, 2600, 2550, 2700},
{1108, "Mumbai", "Delhi", "Mumbai Mail", "12:30", "19:30", "2024-06-06", "2024-06-07", 5300, 2650, 2600, 2750},
{1109, "Delhi", "Kolkata", "Delhi Express", "13:45", "20:45", "2024-06-06", "2024-06-07", 5400, 2700, 2650, 2800},
{1110, "Kolkata", "Pune", "Kolkata Mail", "15:00", "22:00", "2024-06-06", "2024-06-07", 5500, 2750, 2700, 2850}







    };

    // Open the new file for writing
    FILE *fp = fopen("zzz.txt", "w");

    if (fp == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    // Write the array of trains to the file
    for (int i = 0; i < 110; i++) {
        fprintf(fp, "%d,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d,%d \n",
                trains[i].trainNumber, trains[i].departure, trains[i].destination,
                trains[i].trainName, trains[i].departureTime, trains[i].arrivalTime,
                trains[i].departureDate, trains[i].arrivalDate,trains[i].full_ticket_fare,trains[i].half_ticket_fare,trains[i].disabled_fare,trains[i].senior_citizen_fare);
    }

    // Close the file
    fclose(fp);

    printf("Train details have been successfully written to zzz.txt.\n");

    return 0;
}


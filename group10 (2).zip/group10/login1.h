#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERS 100
#define NAME_LENGTH 50
#define PASSWORD_LENGTH 50

typedef struct {
    char username[NAME_LENGTH];
    char password[PASSWORD_LENGTH];
} User;

User users[MAX_USERS];
int numUsers = 0;

void signup() {
    FILE *file1 = fopen("train_file1.txt", "a");
    if (file1 == NULL) {
        printf("Error opening file1.txt\n");
        return;
    }

    printf("Welcome to sign up!\n");
    printf("Enter your username: ");
    scanf("%s", users[numUsers].username);
    fprintf(file1, "%s ", users[numUsers].username);
    printf("Enter your password: ");
    scanf("%s", users[numUsers].password);
    fprintf(file1, "%s\n", users[numUsers].password);
    fclose(file1);

    numUsers++;
    printf("Sign up successful!\n");
}

int login_main() {
    char username[NAME_LENGTH];
    char password[PASSWORD_LENGTH];

    printf("Welcome to login!\n");
    printf("Enter your username: ");
    scanf("%s", username);
    printf("Enter your password: ");
    scanf("%s", password);

    FILE *file1 = fopen("train_file1.txt", "r");
    if (file1 == NULL) {
        printf("Error opening file1.txt\n");
        return 0;
    }

    char fileUsername[NAME_LENGTH];
    char filePassword[PASSWORD_LENGTH];
    int found = 0;
    while (fscanf(file1, "%s %s", fileUsername, filePassword) != EOF) {
        if (strcmp(fileUsername, username) == 0 && strcmp(filePassword, password) == 0) {
            printf("Login successful!\n");
            found = 1;
            break;
        }
    }
    fclose(file1);

    if (!found) {
        printf("Invalid username or password.\n");
        return 0;
    }

    FILE *file2 = fopen("train_file2.txt", "a");
    if (file2 == NULL) {
        printf("Error opening file2.txt\n");
        return 0;
    }
    fprintf(file2, "%s logged in\n", username);
    fclose(file2);

    return 1;
}

void forgotPassword() {
    char username[NAME_LENGTH];
    char newPassword1[PASSWORD_LENGTH];
    char newPassword2[PASSWORD_LENGTH];

    printf("Forgot Password\n");
    printf("Enter your username: ");
    scanf("%s", username);

    FILE *file1 = fopen("train_file1.txt", "r+");
    if (file1 == NULL) {
        printf("Error opening file1.txt\n");
        return;
    }

    char fileUsername[NAME_LENGTH];
    char filePassword[PASSWORD_LENGTH];
    int found = 0;
    long pos;

    while (!found && (pos = ftell(file1)) != -1 && fscanf(file1, "%s %s", fileUsername, filePassword) != EOF) {
        if (strcmp(fileUsername, username) == 0) {
            found = 1;
        }
    }

    if (!found) {
        printf("Username not found.\n");
        fclose(file1);
        return;
    }

    do {
        printf("Enter new password: ");
        scanf("%s", newPassword1);
        printf("Confirm new password: ");
        scanf("%s", newPassword2);

        if (strcmp(newPassword1, newPassword2) != 0) {
            printf("Passwords do not match. Please try again.\n");
        }
    } while (strcmp(newPassword1, newPassword2) != 0);

    fseek(file1, pos, SEEK_SET);
    fprintf(file1, "%s %s\n", fileUsername, newPassword1);
    printf("Password updated successfully!\n");
    fclose(file1);
}

int login1_main() {
    char choice[20];

    while (1) {
        printf("Enter 'signup' to sign up, 'login' to login, or 'forgot' if you forgot your password: ");
        scanf("%s", choice);

        if (strcmp(choice, "signup") == 0) {
            if (numUsers < MAX_USERS) {
                signup();
            } else {
                printf("Maximum number of users reached!\n");
            }
        } else if (strcmp(choice, "login") == 0) {
            if (numUsers > 0) {
                if (login_main()) {
                    break;
                }
            } else {
                printf("No users signed up yet!\n");
            }
        } else if (strcmp(choice, "forgot") == 0) {
            forgotPassword();
        } else {
            printf("Invalid choice.\n");
        }
    }

    return 0;
}


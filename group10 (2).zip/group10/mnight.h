#include <stdio.h>

int mnight_main() {
    FILE *file;
    file = fopen("night.csv", "w");

    if (file == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    fprintf(file, "TrainNumber,DepartureStation,DestinationStation,DepartureTime,ArrivalTime,RACSeats,WaitingListSeats\n");

     fprintf(file, "1001,Salem,Chennai,08:00,14:00,7,15\n");
    fprintf(file, "1002,Chennai,Delhi,10:00,20:00,4,12\n");
    fprintf(file, "1003,Mumbai,Kolkata,12:00,18:00,8,18\n");
    fprintf(file, "1004,Bangalore,Hyderabad,11:30,17:30,5,10\n");
    fprintf(file, "1005,Delhi,Pune,09:15,16:15,6,14\n");
    fprintf(file, "1006,Kolkata,Mumbai,08:45,15:45,9,20\n");
    fprintf(file, "1007,Pune,Hyderabad,10:30,17:30,6,12\n");
    fprintf(file, "1008,Hyderabad,Chennai,11:00,17:00,4,8\n");
    fprintf(file, "1009,Chennai,Bangalore,13:00,19:00,7,16\n");
    fprintf(file, "1010,Bangalore,Delhi,12:30,20:30,10,22\n");
    fprintf(file, "1011,Mumbai,Delhi,09:00,15:00,6,12\n");
    fprintf(file, "1012,Delhi,Chennai,10:30,16:30,5,10\n");
    fprintf(file, "1013,Kolkata,Hyderabad,11:15,17:15,8,15\n");
    fprintf(file, "1014,Chennai,Pune,12:45,18:45,7,14\n");
    fprintf(file, "1015,Pune,Mumbai,08:30,14:30,4,8\n");
    fprintf(file, "1016,Bangalore,Kolkata,07:00,13:00,9,18\n");
    fprintf(file, "1017,Hyderabad,Bangalore,13:30,19:30,6,12\n");
    fprintf(file, "1018,Chennai,Delhi,09:45,15:45,5,10\n");
    fprintf(file, "1019,Delhi,Pune,11:00,17:00,8,16\n");
    fprintf(file, "1020,Mumbai,Chennai,12:15,18:15,7,14\n");
    fprintf(file, "1021,Pune,Hyderabad,08:30,14:30,4,8\n");
    fprintf(file, "1022,Hyderabad,Bangalore,10:15,16:15,9,18\n");
    fprintf(file, "1023,Bangalore,Delhi,11:30,17:30,6,12\n");
    fprintf(file, "1024,Chennai,Kolkata,13:00,19:00,5,10\n");
    fprintf(file, "1025,Kolkata,Mumbai,08:45,14:45,8,16\n");
    fprintf(file, "1026,Mumbai,Pune,10:00,16:00,7,14\n");
    fprintf(file, "1027,Pune,Delhi,11:30,17:30,4,8\n");
    fprintf(file, "1028,Delhi,Hyderabad,12:45,18:45,9,18\n");
    fprintf(file, "1029,Hyderabad,Bangalore,09:15,15:15,6,12\n");
    fprintf(file, "1030,Bangalore,Chennai,10:30,16:30,7,14\n");
    fprintf(file, "1031,Chennai,Kolkata,12:00,18:00,5,10\n");
    fprintf(file, "1032,Hyderabad,Mumbai,08:00,14:00,4,8\n");
    fprintf(file, "1033,Mumbai,Pune,10:30,16:30,9,18\n");
    fprintf(file, "1034,Pune,Delhi,12:15,18:15,6,12\n");
    fprintf(file, "1035,Delhi,Chennai,13:45,19:45,5,10\n");
    fprintf(file, "1036,Chennai,Kolkata,09:00,15:00,8,16\n");
    fprintf(file, "1037,Kolkata,Bangalore,10:45,16:45,7,14\n");
    fprintf(file, "1038,Bangalore,Hyderabad,12:30,18:30,4,8\n");
    fprintf(file, "1039,Hyderabad,Delhi,14:00,20:00,9,18\n");
    fprintf(file, "1040,Delhi,Pune,08:15,14:15,6,12\n");
    fprintf(file, "1041,Pune,Chennai,09:45,15:45,7,14\n");
    fprintf(file, "1042,Chennai,Kolkata,11:30,17:30,5,10\n");
    fprintf(file, "1043,Kolkata,Mumbai,13:00,19:00,8,16\n");
    fprintf(file, "1044,Mumbai,Bangalore,08:30,14:30,4,8\n");
    fprintf(file, "1045,Bangalore,Hyderabad,10:15,16:15,9,18\n");
    fprintf(file, "1046,Hyderabad,Delhi,11:45,17:45,6,12\n");
    fprintf(file, "1047,Delhi,Pune,13:30,19:30,5,10\n");
    fprintf(file, "1048,Pune,Chennai,08:45,14:45,8,16\n");
    fprintf(file, "1049,Chennai,Kolkata,10:30,16:30,7,14\n");
    fprintf(file, "1050,Kolkata,Mumbai,12:15,18:15,4,8\n");
    fprintf(file, "1051,Mumbai,Chennai,08:00,14:00,9,18\n");
    fprintf(file, "1052,Chennai,Kolkata,09:30,15:30,6,12\n");
    fprintf(file, "1053,Kolkata,Delhi,11:15,17:15,5,10\n");
    fprintf(file, "1054,Delhi,Hyderabad,12:45,18:45,8,16\n");
    fprintf(file, "1055,Hyderabad,Pune,14:30,20:30,7,14\n");
    fprintf(file, "1056,Pune,Bangalore,08:00,14:00,4,8\n");
    fprintf(file, "1057,Bangalore,Chennai,09:45,15:45,9,18\n");
    fprintf(file, "1058,Chennai,Mumbai,11:30,17:30,6,12\n");
    fprintf(file, "1059,Mumbai,Kolkata,13:00,19:00,5,10\n");
    fprintf(file, "1060,Kolkata,Delhi,08:30,14:30,8,16\n");
    fprintf(file, "1061,Delhi,Hyderabad,10:15,16:15,7,14\n");
    fprintf(file, "1062,Hyderabad,Pune,11:45,17:45,4,8\n");
    fprintf(file, "1063,Pune,Bangalore,13:30,19:30,9,18\n");
    fprintf(file, "1064,Bangalore,Chennai,08:45,14:45,6,12\n");
    fprintf(file, "1065,Chennai,Mumbai,10:30,16:30,5,10\n");
    fprintf(file, "1066,Mumbai,Kolkata,12:15,18:15,8,16\n");
    fprintf(file, "1067,Kolkata,Delhi,13:45,19:45,7,14\n");
    fprintf(file, "1068,Delhi,Hyderabad,09:00,15:00,4,8\n");
    fprintf(file, "1069,Hyderabad,Pune,10:45,16:45,9,18\n");
    fprintf(file, "1070,Pune,Bangalore,12:30,18:30,6,12\n");
    fprintf(file, "1071,Bangalore,Chennai,08:00,14:00,4,8\n");
    fprintf(file, "1072,Chennai,Hyderabad,09:30,15:30,9,18\n");
    fprintf(file, "1073,Hyderabad,Delhi,11:15,17:15,6,12\n");
    fprintf(file, "1074,Delhi,Mumbai,12:45,18:45,5,10\n");
    fprintf(file, "1075,Mumbai,Kolkata,14:30,20:30,8,16\n");
    fprintf(file, "1076,Kolkata,Pune,08:00,14:00,7,14\n");
    fprintf(file, "1077,Pune,Bangalore,09:45,15:45,4,8\n");
    fprintf(file, "1078,Bangalore,Chennai,11:30,17:30,9,18\n");
    fprintf(file, "1079,Chennai,Hyderabad,13:00,19:00,6,12\n");
    fprintf(file, "1080,Hyderabad,Delhi,08:30,14:30,5,10\n");
    fprintf(file, "1081,Delhi,Mumbai,10:15,16:15,8,16\n");
    fprintf(file, "1082,Mumbai,Kolkata,11:45,17:45,7,14\n");
    fprintf(file, "1083,Kolkata,Pune,13:30,19:30,4,8\n");
    fprintf(file, "1084,Pune,Bangalore,08:45,14:45,9,18\n");
    fprintf(file, "1085,Bangalore,Chennai,10:30,16:30,6,12\n");
    fprintf(file, "1086,Chennai,Hyderabad,12:15,18:15,5,10\n");
    fprintf(file, "1087,Hyderabad,Delhi,13:45,19:45,8,16\n");
    fprintf(file, "1088,Delhi,Mumbai,09:00,15:00,7,14\n");
    fprintf(file, "1089,Mumbai,Kolkata,10:45,16:45,4,8\n");
    fprintf(file, "1090,Kolkata,Pune,12:30,18:30,9,18\n");
    fprintf(file, "1091,Pune,Bangalore,08:00,14:00,6,12\n");
    fprintf(file, "1092,Bangalore,Chennai,09:30,15:30,5,10\n");
    fprintf(file, "1093,Chennai,Hyderabad,11:15,17:15,8,16\n");
    fprintf(file, "1094,Hyderabad,Delhi,12:45,18:45,7,14\n");
    fprintf(file, "1095,Delhi,Mumbai,14:30,20:30,4,8\n");
    fprintf(file, "1096,Mumbai,Kolkata,08:00,14:00,9,18\n");
    fprintf(file, "1097,Kolkata,Pune,09:30,15:30,6,12\n");
    fprintf(file, "1098,Pune,Bangalore,11:15,17:15,5,10\n");
    fprintf(file, "1099,Bangalore,Chennai,12:45,18:45,8,16\n");
    fprintf(file, "1100,Chennai,Hyderabad,08:30,14:30,7,14\n");

    fclose(file);
    printf("File 'night.csv' written successfully!\n");

    return 0;
}


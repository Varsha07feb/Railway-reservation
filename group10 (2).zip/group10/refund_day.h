#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

struct User1 {
    char name[100];
    char phoneNumber[15];
    char upiID[50];
    char bankName[50];
    char bankNumber[20];
    char bankPassword[20];
    float balance;
};

int readUsers1FromFile(struct User1 users[], int maxUsers, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file for reading");
        return -1;
    }

    int count = 0;
    while (fscanf(file, "%99[^,],%14[^,],%49[^,],%49[^,],%19[^,],%19[^,],%f\n",
                  users[count].name, users[count].phoneNumber, users[count].upiID,
                  users[count].bankName, users[count].bankNumber, users[count].bankPassword,
                  &users[count].balance) == 7) {
        count++;
        if (count >= maxUsers) {
            break;
        }
    }

    fclose(file);
    return count;
}

struct User1* findUser1ByUPI(struct User1 users[], int count, const char *upiID) {
    for (int i = 0; i < count; ++i) {
        if (strcmp(users[i].upiID, upiID) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

struct User1* findUser1ByBankNumber(struct User1 users[], int count, const char *bankNumber) {
    for (int i = 0; i < count; ++i) {
        if (strcmp(users[i].bankNumber, bankNumber) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

void updateUsers1File(struct User1 users[], int count, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Error opening file for writing");
        return;
    }

    for (int i = 0; i < count; ++i) {
        fprintf(file, "%s,%s,%s,%s,%s,%s,%.2f\n",
                users[i].name,
                users[i].phoneNumber,
                users[i].upiID,
                users[i].bankName,
                users[i].bankNumber,
                users[i].bankPassword,
                users[i].balance);
    }

    fclose(file);
}
/*

void updateFareFile(const struct User1 *user, float fareAmount, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (!file) {
        perror("Error opening file for appending");
        return;
    }

    fprintf(file, "%s,%s,%s,%s,%s,%s,%.2f\n",
            user->name,
            user->phoneNumber,
            user->upiID,
            user->bankName,
            user->bankNumber,
            user->bankPassword,
            user->balance);

    fclose(file);
}*/

int generate_PNR() {
    return rand() % 900000 + 100000; // Generates a random 6-digit number
}

void save_PNRToFile(const char *name, int pnr, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (!file) {
        perror("Error opening file for appending");
        return;
    }

    fprintf(file, "%s,%d\n", name, pnr);
    fclose(file);
}

// Function to check if the name exists in the PNR_NEW.csv file and print the PNR number if it does
int checkNameInPNRFile(char* name) {
    FILE* file = fopen("PNR_NEW3.csv", "r");
    if (file != NULL) {
        char pnrFromFile[50];
        char nameFromFile[50];

        while (fscanf(file, "%[^,],%[^\n]\n", pnrFromFile, nameFromFile) == 2) {
            if (strcmp(nameFromFile, name) == 0) {
                printf("PNR Number: %s\n", pnrFromFile);
                fclose(file);
                return 1; // Name found
            }
        }
        fclose(file);
    }
    return 0; // Name not found
}

// Function to verify PNR and name in the PNR_NEW.csv file
int verifyPnr(char* PNR, char* name) {
    FILE* file = fopen("PNR_NEW3.csv", "r");
    if (file != NULL) {
        char pnrFromFile[50];
        char nameFromFile[50];

        while (fscanf(file, "%[^,],%[^\n]\n", pnrFromFile, nameFromFile) == 2) {
            if (strcmp(pnrFromFile, PNR) == 0 && strcmp(nameFromFile, name) == 0) {
                fclose(file);
                return 1; // PNR and name found
            }
        }
        fclose(file);
    }
    return 0; // PNR or name not found
}

// Function to cancel the booking
void cancel_Booking(float tic_price, int days) {
    if (days > 25) {
        printf("You will get refunded completely $%.2f within a week. For any queries, contact us.\n", tic_price);
    } else if (days >= 5) {
        printf("You will get $%.2f refunded within a week. For any queries, contact us.\n", tic_price * 0.75);
    } else if (days > 1) {
        printf("$%.2f will be refunded within a week. For any queries, contact us.\n", tic_price * 0.5);
    } else {
        printf("Dear user, you cancelled the ticket too late. There's no money to be refunded. For any queries, contact us.\n");
    }
}

int refundday_main() {
    struct User1 users[100];
    int userCount = readUsersFromFile(users, 100, "personal_detailn2.csv");
    if (userCount == -1) {
        return 1;
    }

    srand(time(NULL)); // Initialize random seed

    char paymentMode[10];
    char input[50];
    float fareAmount;

    printf("Do you need to cancel a ticket? (1 for Yes / 0 for No): ");
    int cancelChoice;
    scanf("%d", &cancelChoice);
    getchar(); // Clear newline character from buffer

    if (cancelChoice == 1) {
        printf("Enter your name: ");
        fgets(input, sizeof(input), stdin);
        strtok(input, "\n"); // Remove newline character

        if (checkNameInPNRFile(input)) {
            printf("Do you want to cancel the ticket? (1 for Yes / 0 for No): ");
            scanf("%d", &cancelChoice);
            getchar(); // Clear newline character from buffer

            if (cancelChoice == 1) {
                printf("Enter your PNR number: ");
                fgets(input, sizeof(input), stdin);
                strtok(input, "\n"); // Remove newline character

                char name[100];
                printf("Enter your name again: ");
                fgets(name, sizeof(name), stdin);
                strtok(name, "\n"); // Remove newline character

                if (verifyPnr(input, name)) {
                    printf("PNR and name verified successfully.\n");

                    printf("Enter the ticket payment price: ");
                    scanf("%f", &fareAmount);
                    printf("How many days from today did you book the ticket initially: ");
                    int days;
                    scanf("%d", &days);

                    cancel_Booking(fareAmount, days);
                    printf("BOOKING CANCELLATION IS SUCCESSFUL.\n");
                } else {
                    printf("Invalid PNR number or name. Please try again.\n");
                }
            } else {
                printf("Booking cancellation aborted.\n");
            }
        } else {
            printf("Name not found. No PNR number associated with this name.\n");
        }
    } else {
        printf("Enter the payment mode (UPI/BANK): ");
        scanf("%9s", paymentMode);

        struct User *foundUser = NULL;

        if (strcmp(paymentMode, "UPI") == 0) {
            printf("Enter UPI ID: ");
            scanf("%49s", input);
            foundUser = findUserByUPI(users, userCount, input);
        } else if (strcmp(paymentMode, "BANK") == 0) {
            printf("Enter Bank Number: ");
            scanf("%19s", input);
            foundUser = findUserByBankNumber(users, userCount, input);
        } else {
            printf("Invalid payment mode.\n");
            return 1;
        }

        if (foundUser) {
            printf("Enter fare amount: ");
            scanf("%f", &fareAmount);

            //if (foundUser->balance >= fareAmount) {
               // foundUser->balance -= fare
                           if (foundUser->balance >= fareAmount) {
                foundUser->balance -= fareAmount;
                printf("Payment successful. New balance: %.2f\n", foundUser->balance);
                // Update the user's information in the original file
                //updateUsersFile(users, userCount, "abcde.csv");
                // Append the updated balance to the up.csv file
                //updateFareFile(foundUser, fareAmount, "up.csv");

                // Generate PNR number and save it with the user's name
                int pnr = generatePNR();
                //savePNRToFile(foundUser->name, pnr, "PNR_NEW3.csv");
                printf("PNR generated: %d\n", pnr);
            } else {
                printf("Insufficient balance. Payment failed.\n");
            }
        } else {
            printf("User not found.\n");
        }
    }

    return 0;
}



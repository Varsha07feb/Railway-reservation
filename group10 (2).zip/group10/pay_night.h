
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

struct User2 {
    char name[100];
    char phoneNumber[15];
    char upiID[50];
    char bankName[50];
    char bankNumber[20];
    char bankPassword[20];
    float balance;
};

int readUsers2FromFile(struct User2 users[], int maxUsers, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file for reading");
        return -1;
    }

    int count = 0;
    while (fscanf(file, "%99[^,],%14[^,],%49[^,],%49[^,],%19[^,],%19[^,],%f\n",
                  users[count].name, users[count].phoneNumber, users[count].upiID,
                  users[count].bankName, users[count].bankNumber, users[count].bankPassword,
                  &users[count].balance) == 7) {
        count++;
        if (count >= maxUsers) {
            break;
        }
    }

    fclose(file);
    return count;
}

struct User2* findUser2ByUPI(struct User2 users[], int count, const char *upiID) {
    for (int i = 0; i < count; ++i) {
        if (strcmp(users[i].upiID, upiID) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

struct User2* findUser2ByBankNumber(struct User2 users[], int count, const char *bankNumber) {
    for (int i = 0; i < count; ++i) {
        if (strcmp(users[i].bankNumber, bankNumber) == 0) {
            return &users[i];
        }
    }
    return NULL;
}

void updateUsers2File(struct User2 users[], int count, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Error opening file for writing");
        return;
    }

    for (int i = 0; i < count; ++i) {
        fprintf(file, "%s,%s,%s,%s,%s,%s,%.2f\n",
                users[i].name,
                users[i].phoneNumber,
                users[i].upiID,
                users[i].bankName,
                users[i].bankNumber,
                users[i].bankPassword,
                users[i].balance);
    }

    fclose(file);
}

int generate_PNR() {
    return rand() % 900000 + 100000; // Generates a random 6-digit number
}

void save_PNRToFile(const char *name, int pnr, const char *filename) {
    FILE *file = fopen(filename, "a");
    if (!file) {
        perror("Error opening file for appending");
        return;
    }

    fprintf(file, "%s,%d\n", name, pnr);
    fclose(file);
}

void paymentProcess() {
    struct User2 users[100];
    int userCount = readUsers1FromFile(users, 100, "night_bank3.csv");
    if (userCount == -1) {
        return;
    }

    srand(time(NULL)); // Initialize random seed

    char paymentMode[10];
    char input[50];
    float fareAmount;

    printf("Enter the payment mode (UPI/BANK): ");
    scanf("%9s", paymentMode);

    struct User2 *foundUser = NULL;

    if (strcmp(paymentMode, "UPI") == 0) {
        printf("Enter UPI ID: ");
        scanf("%49s", input);
        foundUser = findUser2ByUPI(users, userCount, input);
    } else if (strcmp(paymentMode, "BANK") == 0) {
        printf("Enter Bank Number: ");
        scanf("%19s", input);
        foundUser = findUser2ByBankNumber(users, userCount, input);
    } else {
        printf("Invalid payment mode.\n");
        return;
    }

    if (foundUser) {
        printf("Enter fare amount: ");
        scanf("%f", &fareAmount);

        if (foundUser->balance >= fareAmount) {
            foundUser->balance -= fareAmount;
            printf("Payment successful. New balance: %.2f\n", foundUser->balance);

            // Update the user's information in the original file
            //updateUsers1File(users, userCount, "personal_detailn2.csv");

            // Generate PNR number and save it with the user's name
            int pnr = generate_PNR();
            //save_PNRToFile(foundUser->name, pnr, "PNR_NEW3.csv");
            printf("PNR generated: %d\n", pnr);
        } else {
            printf("Insufficient balance. Payment failed.\n");
        }
    } else {
        printf("User not found.\n");
    }
}

int paynight_main() {
    paymentProcess();
    return 0;
}

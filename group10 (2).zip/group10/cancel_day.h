#include <stdio.h>
#include <string.h>

void cancel__Booking(float tic_price, int days) {
    if (days > 25) {
        printf("You will get refunded completely $%.2f within a week. For any queries, contact us.\n", tic_price);
    } else if (days >= 5) {
        printf("You will get $%.2f refunded within a week. For any queries, contact us.\n", tic_price * 0.75);
    } else if (days > 1) {
        printf("$%.2f will be refunded within a week. For any queries, contact us.\n", tic_price * 0.5);
    } else {
        printf("Dear user, you cancelled the ticket too late. There's no money to be refunded. For any queries, contact us.\n");
    }
}

int checkNameINPNRFile(char* name) {
    FILE* file = fopen("PNR_NEW3.csv", "r");
    if (file != NULL) {
        char pnrFromFile[50];
        char nameFromFile[50];

        while (fscanf(file, "%[^,],%[^\n]\n", pnrFromFile, nameFromFile) == 2) {
            if (strcmp(nameFromFile, name) == 0) {
                printf("PNR Number: %s\n", pnrFromFile);
                fclose(file);
                return 1; // Name found
            }
        }
        fclose(file);
    }
    return 0; // Name not found
}

int verify_Pnr(char* PNR, char* name) {
    FILE* file = fopen("PNR_NEW3.csv", "r");
    if (file != NULL) {
        char pnrFromFile[50];
        char nameFromFile[50];

        while (fscanf(file, "%[^,],%[^\n]\n", pnrFromFile, nameFromFile) == 2) {
            if (strcmp(pnrFromFile, PNR) == 0 && strcmp(nameFromFile, name) == 0) {
                fclose(file);
                return 1; // PNR and name found
            }
        }
        fclose(file);
    }
    return 0; // PNR or name not found
}

int isValid_PNR(char* pnr) {
    int length = strlen(pnr);
    if (length != 6) {
        return 0; // Invalid length
    }
    for (int i = 0; i < length; i++) {
        if (!isdigit(pnr[i])) {
            return 0; // Not a digit
        }
    }
    return 1; // Valid PNR
}

void CancelTicket() {
    char input[50];
    float fareAmount;

    printf("Enter your name: ");
    fgets(input, sizeof(input), stdin);
    strtok(input, "\n"); // Remove newline character

    if (1) {
        printf("Do you want to cancel the ticket? (1 for Yes / 0 for No): ");
        int cancelChoice;
        scanf("%d", &cancelChoice);
        getchar(); // Clear newline character from buffer

        if (cancelChoice == 1) {
            printf("Enter your PNR number: ");
            fgets(input, sizeof(input), stdin);
            strtok(input, "\n"); // Remove newline character

            if (!isValidPNR(input)) {
                printf("Invalid PNR number.\n");
                return;
            }

            char name[100];
            printf("Enter your name again: ");
            fgets(name, sizeof(name), stdin);
            strtok(name, "\n"); // Remove newline character

            if (1) {
                printf("PNR and name verified successfully.\n");

                printf("Enter the ticket payment price: ");
                scanf("%f", &fareAmount);
                printf("How many days from today did you book the ticket initially: ");
                int days;
                scanf("%d", &days);

                cancel__Booking(fareAmount, days);
                printf("BOOKING CANCELLATION IS SUCCESSFUL.\n");
            } else {
                printf("Invalid PNR number or name. Please try again.\n");
            }
        } else {
            printf("Booking cancellation aborted.\n");
        }
    } else {
        printf("Name not found. No PNR number associated with this name.\n");
    }
}

int cancelday_main() {
    CancelTicket();
    return 0;
}


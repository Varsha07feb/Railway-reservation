/*#define MAX_USERS 100
#define NAME_LENGTH 50
#define PASSWORD_LENGTH 50

typedef struct {
    char username[NAME_LENGTH];
    char password[PASSWORD_LENGTH];
} User;

User users[MAX_USERS];
int numUsers;

void signup();
int login();
void forgotPassword();
void login_main();

struct Train {
    int trainNumber;
    char departure[50];
    char destination[50];
    char trainName[50];
    char departureTime[10];
    char arrivalTime[10];
    char departureDate[11];
    char arrivalDate[11];
    int full_ticket_fare;
    int half_ticket_fare;
    int disabled_fare;
    int senior_citizen_fare;
};

void train_save();

struct Train {
    int trainNumber;
    char departure[50];
    char destination[50];
    char trainName[50];
    char departureTime[10];
    char arrivalTime[10];
    char departureDate[11];
    char arrivalDate[11];
    int full_ticket_fare;
    int half_ticket_fare;
    int disabled_fare;
    int senior_citizen_fare;
};

void trim(char* );
int search_main();

struct Passenger {
    char name[50];
    char gender;
    int trainNumber;
    char travelClass[20];
    int age;
    char mobileNumber[15];
    bool isDisabled;
    int fare;
    int totalFare;
};

#define SLEEPER_COACHES 12
#define SLEEPER_BERTHS 72
#define AC3_COACHES 4
#define AC3_BERTHS 64
#define AC2_COACHES 3
#define AC2_BERTHS 32
#define AC1_COACHES 1
#define AC1_BERTHS 16

const char *sleeper_berths[] = {"U", "M", "L", "SU", "SL"};
const char *ac_berths[] = {"U", "L"};

struct Passenger passengers[100];
int passengerCount;

bool isValidMobileNumber(const char*);
void display_compartments(char );
bool is_berth_booked(char , int , int );
void book_berth(char , int , int , struct Passenger passenger );
void display_available_lower_berths(char , int );
void display_booked_seats(char , int);
int calculate_fare(int , int , bool );
struct Passenger *find_passenger_by_mobile(const char* );
void add_or_update_passenger(struct Passenger);
void display_total_fare(const struct Passenger *passenger);
int try12_main();

struct Passenger {
    char name[50];
    char phone_number[20];
    char upi_id[50];
    char bank_name[50];
    char bank_number[20];
    char bank_password[50];
    double balance;
};

int is_valid_phone_number(char *);
int check_name_and_number(char*, char* );
void get_passenger_details(struct Passenger* );
void save_to_csv(struct Passenger *);
int try15_main();

#define MAX_USERS 100
#define MAX_TRAINS 50

struct User {
    char name[50];
    char phoneNumber[15];
    char upiID[50];
    char bankName[50];
    char bankNumber[20];
    char bankPassword[20];
    double balance;
};


struct Passenger {
    char name[50];
    char phoneNumber[15];
    char pnr[11];
    char paymentStatus[20];
    char paymentMode[20];
};

void generatePNR(char pnr[]);
int loadUsers(struct User , int );
void updateUsers(struct User users[], int );
void savePassenger(struct Passenger passenger);
int verifyPNR(char*, char*);
void cancelBooking(struct User users[], int , char* , char*, double );
void clearInputBuffer();
int vid2_main();
*/


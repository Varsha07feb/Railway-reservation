#include<stdio.h>
#include"login1.h"
#include"savetrain.h"
//#include"connecttrain.h"
#include"cf.h"
#include"nighttrain.h"
#include"try15.h"
#include"searchtrain.h"
#include"pay_night.h"
#include"cancel_night.h"
#include"pay_day.h"
#include"cancel_day.h"
#include"tha3.h"
#include"mnight.h"
#include"mnight2.h"
#include"mday.h"
#include"mday2.h"
#include"va.h"


int n,choice,n1,n2,n3,n4,n5,n6,n7,n8,n9,n0;
int main(){
printf("\n=========================================================================================================");
printf("\n *********************************************************************************************************");
printf("\n");
printf("            #############           RAILWAY RESERVTION SYSTEM         ##############                        ");
printf("\n");
printf("\n");
printf("\n *********************************************************************************************************");
printf("\n==========================================================================================================");

printf("\n hi!!!!!!!!!!!!!!!!!!!!");
printf("\n you are in login ");
login1_main();
exm7_main();
search4_main();
printf("\n incase of unavailability of train  give 1 or give 0");
printf("\n enter the number:");
scanf("%d",&n);
if(n==1)
{
    //connect_main();
    cf_main();
     printf("you are in booking");
    printf("\n enter 1 for night train and 2 for day train :");
    scanf("%d",&n1);
    if(n1==1){
    va_main();
    try12_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n2);
    if(n2==1){
        mnight_main();
        mnight2_main();
        try15_main();
        paynight_main();
        printf("\n enter 1 if you need to cancel the ticket ,else 0");
        printf("\n enter the number:");
        scanf("%d",&n4);
        if(n4==1){
            cancelnight_main();
    }}
    else{
         try15_main();
        paynight_main();
        printf("\n enter 1 if you need to cancel the ticket ,else 0");
        printf("\n enter the number:");
        scanf("%d",&n5);
        if(n5==1){
            cancelnight_main();
    }

    }

    }
    else{
    tha3_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n6);
    if(n6==1){
        mday_main();
        mday2_main();
        payday_main();
        printf(" printf 1 for cancellation else 0");
        printf("\n enter the number:");
        scanf("%d",&n7);
        if(n7==1){
        cancelday_main();
    }}
    else{
        payday_main();
        printf(" printf 1 for cancellation else 0");
        printf("\n enter the number:");
        scanf("%d",&n8);
        if(n8==1){
        cancelday_main();


    }
}
}}
else
{
    printf("you are in booking");
    printf("\n enter 1 for night train and 2 for day train :");
    scanf("%d",&n1);
    if(n1==1){
    va_main();
    try12_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n2);
    if(n2==1){
        mnight_main();
        mnight2_main();
        try15_main();
        paynight_main();
        printf("\n enter 1 if you need to cancel the ticket ,else 0");
        printf("\n enter the number:");
        scanf("%d",&n4);
        if(n4==1){
            cancelnight_main();
    }}
    else{
         try15_main();
        paynight_main();
        printf("\n enter 1 if you need to cancel the ticket ,else 0");
        printf("\n enter the number:");
        scanf("%d",&n5);
        if(n5==1){
            cancelnight_main();
    }

    }

    }
    else{
    tha3_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n6);
    if(n6==1){
        mday_main();
        mday2_main();
        payday_main();
        printf(" printf 1 for cancellation else 0");
        printf("\n enter the number:");
        scanf("%d",&n7);
        if(n7==1){
        cancelday_main();
    }}
    else{
        payday_main();
        printf(" printf 1 for cancellation else 0");
        printf("\n enter the number:");
        scanf("%d",&n8);
        if(n8==1){
        cancelday_main();


    }
}
}}}



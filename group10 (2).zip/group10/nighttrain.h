#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

struct Passenger {
    char name[50];
    char gender;
    int trainNumber;
    char travelClass[20];
    int age;
    char mobileNumber[15];
    bool isDisabled;
    int fare;
    int totalFare;
};

#define SLEEPER_COACHES 12
#define SLEEPER_BERTHS 72
#define AC3_COACHES 4
#define AC3_BERTHS 64
#define AC2_COACHES 3
#define AC2_BERTHS 32
#define AC1_COACHES 1
#define AC1_BERTHS 16

const char *sleeper_berths[] = {"U", "M", "L", "SU", "SL"};
const char *ac_berths[] = {"U", "L"};

struct Passenger passengers[100];
int passengerCount = 0;

bool isValidMobileNumber(const char *mobileNumber) {
    int length = strlen(mobileNumber);
    if (length != 10) {
        return false;
    }
    for (int i = 0; i < length; i++) {
        if (!isdigit(mobileNumber[i])) {
            return false;
        }
    }
    return true;
}

void display_compartments(char coach_type) {
    printf("Compartments:\n");
    if (coach_type == 'S') {
        printf("1. Upper (U)\n");
        printf("2. Middle (M)\n");
        printf("3. Lower (L)\n");
        printf("4. Side Upper (SU)\n");
        printf("5. Side Lower (SL)\n");
    } else if (coach_type == 'A' || coach_type == 'B' || coach_type == 'C') {
        printf("1. Upper (U)\n");
        printf("2. Lower (L)\n");
    }
}

bool is_berth_booked(char coach_type, int coach_number, int berth_number) {
    FILE *file = fopen("booked_seats.txt", "r");
    if (file == NULL) {
        return false;
    }
    char type;
    int coach, berth;
    while (fscanf(file, "%c %d %d\n", &type, &coach, &berth) != EOF) {
        if (type == coach_type && coach == coach_number && berth == berth_number) {
            fclose(file);
            return true;
        }
    }
    fclose(file);
    return false;
}

void book_berth(char coach_type, int coach_number, int berth_number, struct Passenger passenger) {
    FILE *file = fopen("booked_seats.txt", "a");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }
    fprintf(file, "%c %d %d\n", coach_type, coach_number, berth_number);
    fclose(file);

    FILE *passenger_file = fopen("passenger_info.txt", "a");
    if (passenger_file == NULL) {
        printf("Error opening passenger info file.\n");
        return;
    }
    fprintf(passenger_file, "Passenger Name: %s, Gender: %c, Train Number: %d, Class: %s, Age: %d, Mobile Number: %s, Disabled: %s, Coach: %c, Berth: %d, Fare: %d\n",
            passenger.name, passenger.gender, passenger.trainNumber, passenger.travelClass, passenger.age, passenger.mobileNumber,
            passenger.isDisabled ? "Yes" : "No", coach_type, berth_number, passenger.fare);
    fclose(passenger_file);

    // Append to anu.csv
    FILE *csv_file = fopen("abc.csv", "a");
    if (csv_file == NULL) {
        printf("Error opening CSV file.\n");
        return;
    }
    fprintf(csv_file, "%s,%s,%d\n", passenger.name, passenger.mobileNumber, passenger.fare);
    fclose(csv_file);
}

void display_available_lower_berths(char coach_type, int total_berths) {
    printf("Available lower berths:\n");
    for (int i = 1; i <= total_berths; i++) {
        if (strcmp(ac_berths[(i - 1) % 2], "L") == 0 && !is_berth_booked(coach_type, (i - 1) / 2 + 1, i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

void display_booked_seats(char coach_type, int coach_number) {
    printf("Booked seats in Coach %c%d:\n", coach_type, coach_number);
    FILE *file = fopen("booked_seats.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }
    char type;
    int coach, berth;
    while (fscanf(file, "%c %d %d\n", &type, &coach, &berth) != EOF) {
        if (type == coach_type && coach == coach_number) {
            printf("Seat %c%d%d is already booked.\n", type, coach, berth);
        }
    }
    fclose(file);
}

int calculate_fare(int trainNumber, int age, bool isDisabled) {
    FILE *file = fopen("vavi1.txt", "r");
    if (file == NULL) {
        printf("Error opening fare details file.\n");
        return -1;
    }
    int train, fullFare, halfFare, disabledFare, seniorCitizenFare;
    while (fscanf(file, "%d %d %d %d %d\n", &train, &fullFare, &halfFare, &disabledFare, &seniorCitizenFare) != EOF) {
        if (train == trainNumber) {
            fclose(file);
            if (isDisabled) {
                return disabledFare;
            } else if (age <= 12) {
                return halfFare;
            } else if (age >= 60) {
                return seniorCitizenFare;
            } else {
                return fullFare;
            }
        }
    }
    fclose(file);
    return -1; // Train number not found
}

struct Passenger *find_passenger_by_mobile(const char *mobileNumber) {
    for (int i = 0; i < passengerCount; i++) {
        if (strcmp(passengers[i].mobileNumber, mobileNumber) == 0) {
            return &passengers[i];
        }
    }
    return NULL;
}

void add_or_update_passenger(struct Passenger passenger) {
    struct Passenger *existing_passenger = find_passenger_by_mobile(passenger.mobileNumber);
    if (existing_passenger != NULL) {
        existing_passenger->totalFare += passenger.fare;
    } else {
        passenger.totalFare = passenger.fare;
        passengers[passengerCount++] = passenger;
    }
}

void display_total_fare(const struct Passenger *passenger) {
    printf("Booking successful! Fare amount for this ticket: %d\n", passenger->fare);
    printf("Total fare for passenger %s (%d, %s): %d\n", passenger->name, passenger->age, passenger->mobileNumber, passenger->totalFare);
}

int try12_main() {
    int choice;

    printf("Welcome to the train booking system!\n");

    while (true) {
        printf("Choose a coach:\n");
        printf("1. Sleeper Class\n");
        printf("2. AC 3 Tier\n");
        printf("3. AC 2 Tier\n");
        printf("4. AC First Class\n");
        printf("5. Exit\n");
        scanf("%d", &choice);

        if (choice == 5) {
            printf("Exiting...\n");
            break;
        }

        int coach_number, berth_number;
        struct Passenger passenger;

        printf("Enter passenger name: ");
        scanf("%s", passenger.name);

        do {
            printf("Enter passenger gender (M/F): ");
            scanf(" %c", &passenger.gender);
            if (passenger.gender != 'M' && passenger.gender != 'F' && passenger.gender != 'm' && passenger.gender != 'f') {
                printf("Invalid gender. Please enter 'M' for male or 'F' for female.\n");
            }
        } while (passenger.gender != 'M' && passenger.gender != 'F' && passenger.gender != 'm' && passenger.gender != 'f');

        do {
            printf("Enter train number (1001 to 1127): ");
            scanf("%d", &passenger.trainNumber);
            if (passenger.trainNumber < 1001 || passenger.trainNumber > 1127) {
                printf("Invalid train number. Please enter a number between 1001 and 1127.\n");
            }
        } while (passenger.trainNumber < 1001 || passenger.trainNumber > 1127);

        do {
            printf("Enter passenger age (0 to 100): ");
            scanf("%d", &passenger.age);
            if (passenger.age < 0 || passenger.age > 100) {
                printf("Invalid age. Please enter an age between 0 and 100.\n");
            }
        } while (passenger.age < 0 || passenger .age > 100);

        do {
            printf("Is the passenger disabled? (1 for Yes, 0 for No): ");
            scanf("%d", &passenger.isDisabled);
            if (passenger.isDisabled != 0 && passenger.isDisabled != 1) {
                printf("Invalid input. Please enter 1 for Yes or 0 for No.\n");
            }
        } while (passenger.isDisabled != 0 && passenger.isDisabled != 1);

        do {
            printf("Enter mobile number (10 digits): ");
            scanf("%s", passenger.mobileNumber);
            if (!isValidMobileNumber(passenger.mobileNumber)) {
                printf("Invalid mobile number. Please enter a 10-digit number.\n");
            }
        } while (!isValidMobileNumber(passenger.mobileNumber));
    passenger.fare = calculate_fare(passenger.trainNumber, passenger.age, passenger.isDisabled);
if (passenger.fare == -1) {
    printf("Failed to calculate fare. Booking failed.\n");
    continue;
}
printf("Fare calculated: %d\n", passenger.fare);

        switch (choice) {
            case 1:
                strcpy(passenger.travelClass, "Sleeper Class");
                printf("Number of coaches in Sleeper Class: %d\n", SLEEPER_COACHES);
                printf("Berths in Sleeper Class:\n");
                for (int i = 1; i <= SLEEPER_BERTHS; i++) {
                    printf("S%d%s ", i, sleeper_berths[(i - 1) % 5]);
                    if (i % 5 == 0) {
                        printf("\n");
                    }
                }
                printf("\n");
                printf("Enter coach number (1 to %d): ", SLEEPER_COACHES);
                scanf("%d", &coach_number);
                if (coach_number < 1 || coach_number > SLEEPER_COACHES) {
                    printf("Invalid coach number.\n");
                    continue;
                }
                display_booked_seats('S', coach_number);
                display_compartments('S');
                printf("Enter berth number (1 to %d): ", SLEEPER_BERTHS);
                scanf("%d", &berth_number);
                if (berth_number < 1 || berth_number > SLEEPER_BERTHS || is_berth_booked('S', coach_number, berth_number)) {
                    printf("Invalid or already booked berth number.\n");
                    continue;
                }
                book_berth('S', coach_number, berth_number, passenger);
                add_or_update_passenger(passenger);
                display_total_fare(&passenger);
                break;

            case 2:
                strcpy(passenger.travelClass, "AC 3 Tier");
                printf("Number of coaches in AC 3 Tier: %d\n", AC3_COACHES);
                printf("Berths in AC 3 Tier:\n");
                for (int i = 1; i <= AC3_BERTHS; i++) {
                    printf("B%d%s ", i, ac_berths[(i - 1) % 2]);
                    if (i % 2 == 0) {
                        printf("\n");
                    }
                }
                printf("\n");
                printf("Enter coach number (1 to %d): ", AC3_COACHES);
                scanf("%d", &coach_number);
                if (coach_number < 1 || coach_number > AC3_COACHES) {
                    printf("Invalid coach number.\n");
                    continue;
                }
                display_booked_seats('B', coach_number);
                display_compartments('B');
                printf("Enter berth number (1 to %d): ", AC3_BERTHS);
                scanf("%d", &berth_number);
                if (berth_number < 1 || berth_number > AC3_BERTHS || is_berth_booked('B', coach_number, berth_number)) {
                    printf("Invalid or already booked berth number.\n");
                    continue;
                }
                book_berth('B', coach_number, berth_number, passenger);
                add_or_update_passenger(passenger);
                display_total_fare(&passenger);
                break;

            case 3:
                strcpy(passenger.travelClass, "AC 2 Tier");
                printf("Number of coaches in AC 2 Tier: %d\n", AC2_COACHES);
                printf("Berths in AC 2 Tier:\n");
                for (int i = 1; i <= AC2_BERTHS; i++) {
                    printf("A%d%s ", i, ac_berths[(i - 1) % 2]);
                    if (i % 2 == 0) {
                        printf("\n");
                    }
                }
                printf("\n");
                printf("Enter coach number (1 to %d): ", AC2_COACHES);
                scanf("%d", &coach_number);
                if (coach_number < 1 || coach_number > AC2_COACHES) {
                    printf("Invalid coach number.\n");
                    break;
                }
                if (passenger.age > 65 || passenger.isDisabled) {
                    display_available_lower_berths('A', AC2_BERTHS);
                }

display_booked_seats('A', coach_number); // Added to display booked seats in AC 2 Tier
                while (true) {
                    printf("Enter berth number: ");
                    scanf("%d", &berth_number);
                    if (berth_number < 1 || berth_number > AC2_BERTHS) {
                        printf("Invalid berth number.\n");
                    } else if (is_berth_booked('A', coach_number, berth_number)) {
                        printf("Berth A%d in coach %d is already booked.\n", berth_number, coach_number);
                        display_booked_seats('A', coach_number); // Display booked seats again
                    } else {
                        book_berth('A', coach_number, berth_number, passenger);
                        printf("Berth A%d in coach %d booked successfully!\n", berth_number, coach_number);
                    }
                    printf("Do you want to book another berth in AC 2 Tier? (1 for Yes, 0 for No): ");
                    int option;
                    scanf("%d", &option);
                    if (option == 0) {
                        break;
                    }
                }
                break;

            case 4:
                strcpy(passenger.travelClass, "AC First Class");
                printf("Number of coaches in AC First Class: %d\n", AC1_COACHES);
                printf("Berths in AC First Class:\n");
                for (int i = 1; i <= AC1_BERTHS; i++) {
                    printf("C%d%s ", i, ac_berths[(i - 1) % 2]);
                    if (i % 2 == 0) {
                        printf("\n");
                    }
                }
                printf("\n");
                display_compartments('C');
                printf("Enter coach number (1): ");
                scanf("%d", &coach_number);
                if (coach_number != 1) {
                    printf("Invalid coach number.\n");
                    break;
                }
                if (passenger.age > 65 || passenger.isDisabled) {
                    display_available_lower_berths('C', AC1_BERTHS);
                }
                display_booked_seats('C', coach_number); // Added to display booked seats in AC First Class
                while (true) {
                    printf("Enter berth number: ");
                    scanf("%d", &berth_number);
                    if (berth_number < 1 || berth_number > AC1_BERTHS) {
                        printf("Invalid berth number.\n");
                    } else if (is_berth_booked('C', coach_number, berth_number)) {
                        printf("Berth C%d in coach %d is already booked.\n", berth_number, coach_number);
                        display_booked_seats('C', coach_number); // Display booked seats again
                    } else {
                        book_berth('C', coach_number, berth_number, passenger);
                        printf("Berth C%d in coach %d booked successfully!\n", berth_number, coach_number);
                    }
                    printf("Do you want to book another berth in AC First Class? (1 for Yes, 0 for No): ");
                    int option;
                    scanf("%d", &option);
                    if (option == 0) {
                        break;
                    }
                }
                break;
            default:
                printf("Invalid choice.\n");
                break;
        }
    }
    return 0;
}



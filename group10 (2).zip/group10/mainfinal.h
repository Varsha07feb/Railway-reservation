#include<stdio.h>
#include"login1.h"
#include"savetrain.h"
#include"connecttrain.h"
#include"nighttrain.h"
#include"try15.h"
#include"vid212.h"
#include"vid2.h"
#include"tha3.h"
#include"mnight.h"
#include"mnight2.h"
#include"mday.h"
#include"mday2.h"
#include"va.h"

int n,choice,n1,n2,n3;
int main(){
printf("\n===========================================================================================");
printf("\n");
printf("\n");
printf("                                RAILWAY RESERVTION SYSTEM                                     ");
printf("\n");
printf("\n");
printf("\n");
printf("\n===========================================================================================");

printf("\n hi!!!!!!!!!!!!!!!!!!!!");
printf("you are in login ");
login_main();
exm7_main();
search4_main();
printf("\n incase of unavailability of train  give 1 or give 0");
printf("\n enter the number:");
scanf("%d",&n);
if(n==1)
{
    connect_main();
     printf("you are in booking");
    printf("\n enter 1 for night train and 2 for day train :");
    scanf("%d",&n1);
    if(n1==1){
    va_main();
    try12_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n2);
    if(n2==1){
        mnight_main();
        mnight2_main();
        try15_main();
        vid212_main();
    }
    else{
         try15_main();
        vid212_main();
    }

    }
    else{
    tha3_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n3);
    if(n3==1){
        mday_main();
        mday2_main();
        vid2_main();
    }
    else{
        vid2_main();

    }
}
}
else
{
    printf("you are in booking");
    printf("\n enter 1 for night train and 2 for day train :");
    scanf("%d",&n1);
    if(n1==1){
    va_main();
    try12_main();
    //try15_main();
    //vid212_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n2);
    if(n2==1){
        mnight_main();
        mnight2_main();
        try15_main();
        vid212_main();
    }
    else{
         try15_main();
        vid212_main();
    }

    }
    else{
    tha3_main();
    printf("\n enter 1 if you needed to be add in RAC or WAITING LIST , else give 0");
    scanf("%d",&n3);
    if(n3==1){
        mday_main();
        mday2_main();
        vid2_main();
    }
    else{
        vid2_main();

    }
}}}



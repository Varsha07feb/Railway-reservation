#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TRAINS 100
#define MAX_NAME_LEN 100

typedef struct {
    int trainNumber;
    char departure[MAX_NAME_LEN];
    char destination[MAX_NAME_LEN];
    char trainName[MAX_NAME_LEN];
    char departureTime[MAX_NAME_LEN];
    char arrivalTime[MAX_NAME_LEN];
    char departureDate[MAX_NAME_LEN];
    char arrivalDate[MAX_NAME_LEN];
    int fullFare;
    int halfFare;
    int disabledFare;
    int seniorFare;
} Train;

typedef struct {
    int trainIndex;
    int previous;
} QueueNode;

Train trains[MAX_TRAINS];
int numTrains = 0;

void addTrain(int trainNumber, const char *departure, const char *destination, const char *trainName, const char *departureTime, const char *arrivalTime, const char *departureDate, const char *arrivalDate, int fullFare, int halfFare, int disabledFare, int seniorFare) {
    trains[numTrains].trainNumber = trainNumber;
    strcpy(trains[numTrains].departure, departure);
    strcpy(trains[numTrains].destination, destination);
    strcpy(trains[numTrains].trainName, trainName);
    strcpy(trains[numTrains].departureTime, departureTime);
    strcpy(trains[numTrains].arrivalTime, arrivalTime);
    strcpy(trains[numTrains].departureDate, departureDate);
    strcpy(trains[numTrains].arrivalDate, arrivalDate);
    trains[numTrains].fullFare = fullFare;
    trains[numTrains].halfFare = halfFare;
    trains[numTrains].disabledFare = disabledFare;
    trains[numTrains].seniorFare = seniorFare;
    numTrains++;
}
void clear_input_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}


void findConnection(const char *start, const char *end) {
    int visited[MAX_TRAINS] = {0};
    QueueNode queue[MAX_TRAINS];
    int front = 0, rear = 0;

    // Enqueue starting point
    for (int i = 0; i < numTrains; i++) {
        if (strcmp(trains[i].departure, start) == 0) {
            queue[rear].trainIndex = i;
            queue[rear].previous = -1;
            visited[i] = 1;
            rear++;
        }
    }

    while (front < rear) {
        QueueNode current = queue[front];
        front++;

        if (strcmp(trains[current.trainIndex].destination, end) == 0) {
            // Print path
            int path[MAX_TRAINS];
            int pathLength = 0;
            int index = current.trainIndex;

            while (index != -1) {
                path[pathLength++] = index;
                index = queue[front - 1].previous;
                if (front > 0) front--;
            }

            printf("Connection found:\n");
            for (int i = pathLength - 1; i >= 0; i--) {
                printf("Train Number: %d, From: %s, To: %s, Train Name: %s\n",
                       trains[path[i]].trainNumber, trains[path[i]].departure, trains[path[i]].destination, trains[path[i]].trainName);
            }
            return;
        }

        // Enqueue next connections
        for (int i = 0; i < numTrains; i++) {
            if (!visited[i] && strcmp(trains[current.trainIndex].destination, trains[i].departure) == 0) {
                queue[rear].trainIndex = i;
                queue[rear].previous = current.trainIndex;
                visited[i] = 1;
                rear++;
            }
        }
    }

    printf("No connection found from %s to %s.\n", start, end);
}

int cf_main() {
    addTrain(1001, "Salem", "Chennai", "Salem Express", "08:00", "14:00", "2024-06-06", "2024-06-07", 500, 250, 300, 350);
    addTrain(1002, "Chennai", "Delhi", "Chennai Superfast", "10:00", "20:00", "2024-06-06", "2024-06-08", 800, 400, 480, 560);
    addTrain(1003, "Mumbai", "Kolkata", "Mumbai Mail", "12:00", "18:00", "2024-06-06", "2024-06-07", 700, 350, 420, 490);
    addTrain(1004, "Bangalore", "Hyderabad", "Bangalore Express", "11:30", "17:30", "2024-06-06", "2024-06-07", 600, 300, 360, 420);
    addTrain(1005, "Delhi", "Pune", "Delhi Express", "09:15", "16:15", "2024-06-06", "2024-06-07", 900, 450, 540, 630);
    addTrain(1006, "Kolkata", "Mumbai", "Kolkata Superfast", "08:45", "15:45", "2024-06-06", "2024-06-07", 750, 375, 450, 525);
    addTrain(1007, "Pune", "Hyderabad", "Pune Express", "10:30", "17:30", "2024-06-06", "2024-06-07", 650, 325, 390, 455);
    addTrain(1008, "Hyderabad", "Chennai", "Hyderabad Superfast", "11:00", "17:00", "2024-06-06", "2024-06-07", 550, 275, 330, 385);
    addTrain(1009, "Chennai", "Bangalore", "Chennai Express", "13:00", "19:00", "2024-06-06", "2024-06-07", 850, 425, 510, 595);
    addTrain(1010, "Bangalore", "Delhi", "Bangalore Mail", "12:30", "20:30", "2024-06-06", "2024-06-07", 1000, 500, 600, 700);
    addTrain(1011, "Delhi", "Kolkata", "Delhi Superfast", "14:45", "21:45", "2024-06-06", "2024-06-07", 1200, 600, 300, 900);
    addTrain(1012, "Mumbai", "Pune", "Mumbai Express", "15:30", "22:30", "2024-06-06", "2024-06-07", 1100, 550, 275, 825);
    addTrain(1013, "Pune", "Chennai", "Pune Superfast", "16:45", "23:45", "2024-06-06", "2024-06-07", 1300, 650, 325, 975);
    addTrain(1014, "Chennai", "Hyderabad", "Chennai Mail", "17:00", "00:00", "2024-06-06", "2024-06-07", 900, 450, 225, 675);
    addTrain(1015, "Hyderabad", "Bangalore", "Hyderabad Mail", "18:15", "01:15", "2024-06-06", "2024-06-07", 1000, 500, 250, 750);
    addTrain(1016, "Bangalore", "Mumbai", "Bangalore Superfast", "19:30", "02:30", "2024-06-06", "2024-06-07", 1200, 600, 300, 900);
    addTrain(1017, "Mumbai", "Delhi", "Mumbai Superfast", "20:45", "03:45", "2024-06-06", "2024-06-07", 1100, 550, 275, 825);
    addTrain(1018, "Delhi", "Kolkata", "Delhi Mail", "21:00", "04:00", "2024-06-06", "2024-06-07", 1300, 650, 325, 975);
    addTrain(1019, "Kolkata", "Pune", "Kolkata Express", "22:15", "05:15", "2024-06-06", "2024-06-07", 900, 450, 225, 675);
    addTrain(1020, "Pune", "Chennai", "Pune Express", "09:30", "16:30", "2024-06-06", "2024-06-07", 700, 350, 175, 525);
addTrain(1021, "Chennai", "Hyderabad", "Chennai Mail", "10:45", "17:45", "2024-06-06", "2024-06-07", 800, 400, 200, 600);
addTrain(1022, "Hyderabad", "Bangalore", "Hyderabad Express", "11:15", "18:15", "2024-06-06", "2024-06-07", 900, 450, 225, 675);
addTrain(1023, "Bangalore", "Delhi", "Bangalore Superfast", "12:30", "19:30", "2024-06-06", "2024-06-07", 1000, 500, 250, 750);
addTrain(1024, "Delhi", "Kolkata", "Delhi Express", "13:45", "20:45", "2024-06-06", "2024-06-07", 1100, 550, 275, 825);
addTrain(1025, "Kolkata", "Mumbai", "Kolkata Superfast", "14:00", "21:00", "2024-06-06", "2024-06-07", 1200, 600, 300, 900);
addTrain(1026, "Mumbai", "Pune", "Mumbai Mail", "15:15", "22:15", "2024-06-06", "2024-06-07", 1300, 650, 325, 975);
addTrain(1027, "Pune", "Chennai", "Pune Superfast", "16:30", "23:30", "2024-06-06", "2024-06-07", 1400, 700, 350, 1050);
addTrain(1028, "Chennai", "Hyderabad", "Chennai Express", "17:45", "00:45", "2024-06-06", "2024-06-07", 1500, 750, 375, 1125);
addTrain(1029, "Hyderabad", "Bangalore", "Hyderabad Superfast", "18:00", "01:00", "2024-06-06", "2024-06-07", 1600, 800, 400, 1200);
addTrain(1030, "Bangalore", "Delhi", "Bangalore Express", "19:15", "02:15", "2024-06-06", "2024-06-07", 1700, 850, 425, 1275);
addTrain(1031, "Delhi", "Kolkata", "Delhi Superfast", "20:30", "03:30", "2024-06-06", "2024-06-07", 1800, 900, 450, 1350);
addTrain(1032, "Kolkata", "Mumbai", "Kolkata Mail", "21:45", "04:45", "2024-06-06", "2024-06-07", 1900, 950, 475, 1425);
addTrain(1033, "Mumbai", "Pune", "Mumbai Express", "22:00", "05:00", "2024-06-06", "2024-06-07", 2000, 1000, 500, 1500);
addTrain(1034, "Pune", "Chennai", "Pune Mail", "23:15", "06:15", "2024-06-06", "2024-06-07", 2100, 1050, 525, 1575);
addTrain(1035, "Chennai", "Hyderabad", "Chennai Superfast", "00:30", "07:30", "2024-06-07", "2024-06-08", 2200, 1100, 550, 1650);
addTrain(1036, "Hyderabad", "Bangalore", "Hyderabad Mail", "01:45", "08:45", "2024-06-07", "2024-06-08", 2300, 1150, 575, 1725);
addTrain(1037, "Bangalore", "Delhi", "Bangalore Superfast", "02:00", "09:00", "2024-06-07", "2024-06-08", 2400, 1200, 600, 1800);
addTrain(1038, "Delhi", "Kolkata", "Delhi Mail", "03:15", "10:15", "2024-06-07", "2024-06-08", 2500, 1250, 625, 1875);
addTrain(1039, "Kolkata", "Mumbai", "Kolkata Express", "04:30", "11:30", "2024-06-07", "2024-06-08", 2600, 1300, 650, 1950);
addTrain(1040, "Mumbai", "Pune", "Mumbai Superfast", "05:45", "12:45", "2024-06-07", "2024-06-08", 2700, 1350, 675, 2025);
addTrain(1041, "Pune", "Chennai", "Pune Express", "07:00", "14:00", "2024-06-07", "2024-06-08", 2800, 1400, 700, 2100);
addTrain(1042, "Chennai", "Hyderabad", "Chennai Superfast", "08:15", "15:15", "2024-06-07", "2024-06-08", 2900, 1450, 725, 2175);
addTrain(1043, "Hyderabad", "Bangalore", "Hyderabad Express", "09:30", "16:30", "2024-06-07", "2024-06-08", 3000, 1500, 750, 2250);
addTrain(1044, "Bangalore", "Delhi", "Bangalore Mail", "10:45", "17:45", "2024-06-07", "2024-06-08", 3100, 1550, 775, 2325);
addTrain(1045, "Delhi", "Kolkata", "Delhi Express", "12:00", "19:00", "2024-06-07", "2024-06-08", 3200, 1600, 800, 2400);
addTrain(1046, "Kolkata", "Mumbai", "Kolkata Superfast", "13:15", "20:15", "2024-06-07", "2024-06-08", 3300, 1650, 825, 2475);
addTrain(1047, "Mumbai", "Pune", "Mumbai Mail", "14:30", "21:30", "2024-06-07", "2024-06-08", 3400, 1700, 850, 2550);
addTrain(1048, "Pune", "Chennai", "Pune Superfast", "15:45", "22:45", "2024-06-07", "2024-06-08", 3500, 1750, 875, 2625);
addTrain(1049, "Chennai", "Hyderabad", "Chennai Express", "17:00", "00:00", "2024-06-07", "2024-06-08", 3600, 1800, 900, 2700);
addTrain(1050, "Hyderabad", "Bangalore", "Hyderabad Superfast", "18:15", "01:15", "2024-06-07", "2024-06-08", 3700, 1850, 925, 2775);
addTrain(1051, "Bangalore", "Delhi", "Bangalore Express", "19:30", "02:30", "2024-06-07", "2024-06-08", 1200, 600, 300, 900);
addTrain(1052, "Delhi", "Kolkata", "Delhi Superfast", "20:45", "03:45", "2024-06-07", "2024-06-08", 1100, 550, 275, 825);
addTrain(1053, "Kolkata", "Mumbai", "Kolkata Superfast", "22:00", "05:00", "2024-06-07", "2024-06-08", 1300, 650, 325, 975);
addTrain(1054, "Mumbai", "Chennai", "Mumbai Mail", "23:15", "06:15", "2024-06-07", "2024-06-08", 1400, 700, 350, 1050);
addTrain(1055, "Chennai", "Hyderabad", "Chennai Express", "00:30", "07:30", "2024-06-08", "2024-06-09", 1500, 750, 375, 1125);
addTrain(1056, "Hyderabad", "Pune", "Hyderabad Superfast", "01:45", "08:45", "2024-06-08", "2024-06-09", 1600, 800, 400, 1200);
addTrain(1057, "Pune", "Bangalore", "Pune Express", "03:00", "10:00", "2024-06-08", "2024-06-09", 1700, 850, 425, 1275);
addTrain(1058, "Bangalore", "Delhi", "Bangalore Superfast", "04:15", "11:15", "2024-06-08", "2024-06-09", 1800, 900, 450, 1350);
addTrain(1059, "Delhi", "Kolkata", "Delhi Express", "05:30", "12:30", "2024-06-08", "2024-06-09", 1900, 950, 475, 1425);
addTrain(1060, "Kolkata", "Mumbai", "Kolkata Mail", "06:45", "13:45", "2024-06-08", "2024-06-09", 2000, 1000, 500, 1500);




    char start[MAX_NAME_LEN];
    char end[MAX_NAME_LEN];

    printf("Enter departure location: ");
    //fflush(stdout);
    clear_input_buffer();
    fgets(start, MAX_NAME_LEN, stdin);
    start[strcspn(start, "\n")] = 0; // Remove newline character from input
    //clear_input_buffer();
    printf("\n Enter destination location: ");
    fflush(stdout);
    //clear_input_buffer();
    fgets(end, MAX_NAME_LEN, stdin);
    end[strcspn(end, "\n")] = 0; // Remove newline character from input
    //clear_input_buffer();
    findConnection(start, end);

    return 0;
}

